//Ankita writes

package BackEnd;

import java.util.ArrayList;

public class ErrorCorrection {

    
    private ParityManager pm;

    public ErrorCorrection() {
        pm = new ParityManager();
    }

    // two data blocks failure
    public byte[][] missing2datablock(int blockSize, ArrayList<byte[]> dataBlockList, byte[] Pblock, byte[] Qblock) {

        byte[] pminus2 = new byte[blockSize];
        byte[] qminus2 = new byte[blockSize];

        byte g0 = 0;
        byte g1 = 0;
        int m_count = 0;

        int[] gfilog = new int[dataBlockList.size()];
        for (int i = 0; i < gfilog.length; i++) {
            gfilog[i] = pm.getGfilogValue(i);
        }

        for (int i = 0; i < dataBlockList.size(); i++) {
            byte[] block = dataBlockList.get(i);
            if (block.length > 0) {
                for (int j = 0; j < blockSize; j++) {
                    pminus2[j] ^= block[j];
                    qminus2[j] ^= (byte) pm.GF_Multiplication((byte) gfilog[i], block[j]);
                }
            } 
            else {
                if (m_count == 0) {
                    g0 = (byte) gfilog[i];
                } else {
                    g1 = (byte) gfilog[i];
                }
                m_count++;
            }
        }

        byte[] missing0 = new byte[blockSize];
        byte[] missing1 = new byte[blockSize];

        for (int j = 0; j < blockSize; j++) {

            byte PblockPrime = (byte) (Pblock[j] ^ pminus2[j]);
            byte QblockPrime = (byte) (Qblock[j] ^ qminus2[j]);

            byte g00 = (byte) pm.GF_Division((byte)1,(byte)(g0 ^ g1));
            byte g01 = (byte) pm.GF_Division((byte)1,(byte)(g1 ^ g0));

            byte temp0 = (byte) pm.GF_Multiplication(g1, PblockPrime);
            byte temp1 = (byte) pm.GF_Multiplication(g0, PblockPrime);

            byte inn0 = (byte) (temp0 ^ QblockPrime);
            byte inn1 = (byte) (temp1 ^ QblockPrime);

            missing0[j] = (byte) pm.GF_Multiplication(g00, inn0);
            missing1[j] = (byte) pm.GF_Multiplication(g01, inn1);
        }

        byte[][] missingdatablks = new byte[2][blockSize];
        missingdatablks[0] = missing0;
        missingdatablks[1] = missing1;
        return missingdatablks;
    }

    //P & data block failure
    public byte[][] MissingBlockDataAndP(int blockSize, ArrayList<byte[]> dataBlockList, byte[] Qblock) {

        byte[] qminus1 = new byte[blockSize];
        byte[] missedDataBlock = new byte[blockSize];
        byte[] Pblock = new byte[blockSize];
        int missingBlock = -1;
        //@Daniel, this index you can provide from outside the function call
        for (int i = 0; i < dataBlockList.size(); i++) {
            byte[] block = dataBlockList.get(i);
            if (block.length == 0) {
                missingBlock = i;
                break;
            }
        }
        byte temp0 = (byte) pm.GF_Division((byte) 1, pm.getGfilogValue(missingBlock)); 
        for (int i = 0; i < dataBlockList.size(); i++) {
            byte[] block = dataBlockList.get(i);
            if (block.length > 0) {
            //if (i != missingBlock) {
                for (int j = 0; j < blockSize; j++) {
                    qminus1[j] ^= (byte) pm.GF_Multiplication(pm.getGfilogValue(i), block[j]);

                    byte temp1 = (byte) (Qblock[j] ^ qminus1[j]);
                    missedDataBlock[j] = (byte) pm.GF_Multiplication(temp0, temp1);
                    Pblock[j] ^= block[j];
                }
            }
        }

        for (int j=0;j<blockSize;j++) {
        	Pblock[j] ^= missedDataBlock[j];
        }
        byte[][] dataP = new byte[2][blockSize];
        dataP[0] = missedDataBlock;
        dataP[1] = Pblock;
        return dataP;
    }

    // Q block & data block failure
    public byte[][] MissingDataBlockAndQBlock(int blockSize, ArrayList<byte[]> dataBlockList, byte[] Pblock) {

        byte[] Qblock = new byte[blockSize];
        byte[] missedDataBlock = new byte[blockSize];
        int missing = -1;
        for (int i = 0; i < dataBlockList.size(); i++) {
            byte[] block = dataBlockList.get(i);
            if (block.length > 0) {
                for (int j = 0; j < blockSize; j++) {
                    byte inn0 = (byte) pm.GF_Multiplication((byte) pm.getGfilogValue(i), block[j]); //blk0
                    Qblock[j] ^= inn0;
                    missedDataBlock[j] ^= block[j];
                }
            }
            else {
            	missing = i;
            }
            
        }

        for (int j = 0; j < blockSize; j++) {
            missedDataBlock[j] ^= Pblock[j];
        }
        
        for (int j=0;j<blockSize;j++) {
        	byte inn0 = (byte) pm.GF_Multiplication((byte) pm.getGfilogValue(missing), missedDataBlock[j]); //blk0
            Qblock[j] ^= inn0;
        }

        byte[][] dataQ = new byte[2][blockSize];
        dataQ[0] = missedDataBlock;
        dataQ[1] = Qblock;
        return dataQ;
    }
    //Send in 2D bytes
    //P & Q blocks failure
    public byte[][] Missing_P_Q(int blockSize, byte [][] dataBlockList) {

        byte[] Pblock = pm.calculatePblock(dataBlockList.length,dataBlockList,blockSize);
        byte[] Qblock = pm.calculateQblock(dataBlockList.length,dataBlockList,blockSize);

        byte[][] PQblock = new byte[2][blockSize];
        PQblock[0] = Pblock;
        PQblock[1] = Qblock;

        return PQblock;
    }

    //missing 1 data block
    public byte[] Missing1BlockData(int blockSize, byte[][] dataBlockList, byte[] Pblock) {

        byte[] missing = new byte[blockSize]; 

        for (int i = 0; i < dataBlockList.length; i++) {
            byte[] block = dataBlockList[i];
            if (block.length > 0) {

                for (int j = 0; j < blockSize; j++) {
                    missing[j] ^= block[j];
                }
            }
        }

        for (int j = 0; j < blockSize; j++) {
            missing[j] ^= Pblock[j];
        }

        return missing;
    }

    //missing QBlock
    public byte[] MissingQBlock(int blockSize,byte[][] dataBlockList) {

        byte[] Qblock = pm.calculateQblock(dataBlockList.length,dataBlockList,blockSize);
        return Qblock;

    }

    //missing PBlock
    public byte[] MissingPBlock(int blockSize, byte [][] dataBlockList) {

        byte[] Pblock = pm.calculatePblock(dataBlockList.length,dataBlockList,blockSize);
        return Pblock;
    }
}
