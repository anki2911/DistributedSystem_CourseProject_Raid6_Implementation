package BackEnd;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;


public class ParityManager {
	private RaidManager rm;
	int numofParitybits = 2;
	public int[] gflog, gfilog;
    public int s = 8;
    
	public ParityManager(RaidManager rm) {
		this.rm = rm;
	}
    public ParityManager() {
        this.GenerateTables();
    }
    
    //generate tables for Galois Filed calculation
    private void GenerateTables() {
        int b, index, gf_elements;
        int PrimPoly8 = 0x11d;
        gf_elements = 1 << s;
        gflog = new int[gf_elements];
        gfilog = new int[gf_elements];
        b = 1;
        for (index=0;index<gf_elements-1;index++) {
            gflog[b] = index;
            gfilog[index] = b;
            b <<= 1;
            if ((b & gf_elements) != 0) {
                b ^= PrimPoly8;
            }
        }
    }

    //multiplication in Galois Filed
    public int GF_Multiplication(byte input1, byte input2) {

        int a,b,s,index;
        if (input1 == 0 || input2 == 0) {
            return 0;
        }
        a = (int)(input1 & 0xFF);
        b = (int)(input2 & 0xFF);
        s = (int)(gflog[a] & 0xFF) + (int)(gflog[b] & 0xFF);
        index = (s) % 255;
        
        return gfilog[index];
    }
    
    //division in Galois Filed
    public int GF_Division(byte input1, byte input2) {
        int a,b,s,index;
        if (input1 == 0 || input2 == 0) {
            return 0;
        }
        if (input1 == 1 && input2 == 1) {
            return 1;
        }
        a=(int)(input1 & 0xFF);
        b=(int)(input2 & 0xFF);
        s=(int)(gflog[input1] & 0xFF) - (int) (gflog[input2] & 0xFF);
        index = (s + 255);
        return gfilog[index];
    }
    
    //addition in Galois Filed
    private int GF_Addition(int input1,int input2){
        return input1 ^ input2;
    }

    //calculate for p parity block
    public byte[] calculatePblock(int size,byte[][]dataBlock,int blockSize) {
    	
    	byte[] Pblock = new byte[blockSize];
    	if (size > 1) {
    		for(int j=0;j<blockSize;j++) {
        		Pblock[j] = (byte)0;
        		for (int i=0;i<size;i++) {
        			Pblock[j] = (byte)(0xff & ((int)Pblock[j] ^ (int)dataBlock[i][j]));			
        		}
        	}    		
    	}
    	else
    	{
    		Pblock = dataBlock[0];
    	}
    	return Pblock;
    	
    	
    }
    
    //calculate for q parity block
    public byte[] calculateQblock(int size,byte[][] dataBlock,int blockSize) {
        
    	byte[] Qblock = new byte[blockSize];
        for (int i=0;i<size;i++) {
        	
            if (dataBlock[i].length > 0) {
                byte g = this.getGfilogValue(i);
                for (int j = 0; j < blockSize; j++) {

                    Qblock[j] ^= (byte) this.GF_Multiplication(g,dataBlock[i][j]);
                }
            }
            else{
                System.out.println("Lenght = 0");
            }
        }

        return Qblock;
    }

    public byte getGfilogValue(int index){
        return (byte)this.gfilog[index+1];
    }
	
	
	

//	public void recoverfromHorizontalParity(String corruptDiskNumber) throws IOException {
//		int maxnumofStrip = rm.getnumofStripswithInfo();
//		ArrayList<byte[]> horizontalParity = getHorizontalParity();
//		//
//		
//	}
	
    //calculate and returns horizontal parity
	public ArrayList<byte[]> getHorizontalParity() throws IOException {
		int maxnumofStrip = rm.getnumofStripswithInfo();
		ArrayList<byte[]> horizontalParityList = new ArrayList<>();
		ArrayList<int[]> blockTable = rm.getBlockTable();
		
		int currentStrip = 0;
		for(int[] strip:blockTable) {
			for(int disk=0;disk<strip.length;disk++) {
				if(strip[disk]==2) {
					Path path = Paths.get(rm.getDiskPath(disk)+"/"+currentStrip);
					horizontalParityList.add(Files.readAllBytes(path));
				}
			}
			currentStrip++;
			if(currentStrip == maxnumofStrip) {
				break;
			}
		}
		
		
		
		return horizontalParityList;
	}
	
	//remove unused parity if there is no data stored in the strip
	public void removeUnusedParity() throws IOException {
		int currentStrip=0;
		int maxnumofStrip = rm.getnumofStripswithInfo();
		for(int[] strip:rm.getBlockTable()) {
			if(currentStrip>=maxnumofStrip) {
			
			for(int disk=0;disk<strip.length;disk++) {
				System.out.println("current disk"+disk);
				if(strip[disk]==2) {
					String storeLocation = rm.getDiskPath(disk)+"/"+currentStrip;
					//System.out.println("remove Horizontal Parity block "+"D"+disk+"B"+currentStrip);
					Files.deleteIfExists(Paths.get(storeLocation));
				}else if(strip[disk]==3) {
					String storeLocation = rm.getDiskPath(disk)+"/"+currentStrip;
					//System.out.println("remove Another Parity block "+"D"+disk+"B"+currentStrip);
					Files.deleteIfExists(Paths.get(storeLocation));
				}
			}
			}
			currentStrip++;
			
		}
	}
}
