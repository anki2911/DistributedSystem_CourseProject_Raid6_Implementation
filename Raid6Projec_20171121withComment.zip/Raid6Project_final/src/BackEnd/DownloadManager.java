package BackEnd;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class DownloadManager {

	//download file from file system to user's specific location
	public void downloadFile(java.io.File downloadLocation,String fileName,RaidManager rm, ArrayList<TransferManager> transferManagers) throws Exception {
		ArrayList<byte[]> contentList = rm.getStoredFile(fileName, transferManagers);
		int fileSize = rm.getFileSize(fileName);
		int counter = 0;
		System.out.println("Write to path "+downloadLocation.getPath()+"/"+fileName);
		FileOutputStream out = new FileOutputStream(downloadLocation.getPath()+"/"+fileName);
		byte[] content = new byte[fileSize];
		outerloop:
		for(byte[] bline:contentList) {
			for(byte b:bline) {
				content[counter]=b;
				counter++;
				if(counter==fileSize) {
					break outerloop;
				}
			}
		}
		out.write(content);
		//BufferedWriter bw = new BufferedWriter(new FileWriter(downloadLocation.getPath()+"/"+fileName));
//		System.out.println("Write content:");
//		outerloop:
//		for(byte[] content:contentList) {
//			//System.out.println(content.toString());
//			for(byte b:content) {
//			bw.write(b);
//			System.out.print(b);
//			counter++;
//			if(counter == fileSize) {
//				System.out.println("counter:"+counter);
//				break outerloop;
//			}
//			}
//			
//		}
//		System.out.println();
		out.close();
		//bw.close();
	}
}
