package BackEnd;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class DiskRemover {

	//remove the blocks of the file from the physical disks.
	public void removeFilefromDisk(String fileName, RaidManager rm, ParityManager pm,
			ArrayList<TransferManager> transferManagers) throws IOException {
		System.out.println("removeFilefromDisk");
		ArrayList<String> stripelist = new ArrayList();
		File originalFile = new File(rm.getMasterInfo());
		File tempFile = new File(rm.getMasterInfo() + "tmp");
		BufferedReader bf = new BufferedReader(new FileReader(originalFile));
		BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
		ArrayList<String> blockLocation = new ArrayList<>();
		String line = "";
		while ((line = bf.readLine()) != null) {
			String[] splittedLine = line.split(";");
			if (splittedLine[0].equals(fileName)) {
				line = bf.readLine();
				splittedLine = line.split(";");
				for (int i = 0; i < splittedLine.length; i += 2) {
					blockLocation.add(splittedLine[i]);
				}
				continue;
			} else {
				bw.write(line + System.getProperty("line.separator"));
			}
		}
		bf.close();
		bw.close();

		//update Master Info file
		File folder = new File("./src/MainInterface/");
		File[] directoryListing = folder.listFiles();
		if (directoryListing != null) {
			for (File file : directoryListing) {
				// System.out.println(file.getName().toString());
				if (file.getName().equals("MasterInfo.txt")) {
					// System.out.println("haha");
					file.delete();
				}
			}

		}
		tempFile.renameTo(originalFile);

		stripelist = removeBlock(blockLocation, rm, transferManagers);
		System.out.println("Now the num of strip with info " + rm.getnumofStripswithInfo());
		DiskWriter dw = new DiskWriter(rm, pm, transferManagers);
		dw.calculateParity(stripelist);


	}

	//remove the blocks from physical disks
	public ArrayList<String> removeBlock(ArrayList<String> blockLocation, RaidManager rm,
			ArrayList<TransferManager> transferManagers) throws NumberFormatException, IOException {
		ArrayList<String> stripes = new ArrayList();
		for (String block : blockLocation) {
			int stripNumber = 0;
			String[] splittedLine = block.split("B");
			int diskNumber = Integer.parseInt(splittedLine[0].substring(1, splittedLine[0].length()));
			int blockNumber = Integer.parseInt(splittedLine[1]);
			String storeLocation = rm.getDiskPath(diskNumber) + "/" + splittedLine[1];
			System.out.println("remove block " + "D" + diskNumber + "B" + blockNumber);
			Files.deleteIfExists(Paths.get(storeLocation));
			for (int[] strip : rm.getBlockTable()) {
				if (blockNumber == stripNumber) {
					strip[diskNumber] = 0;
					boolean notfound = true;
					for (String str : stripes) {
						if (str.equals(Integer.toString(stripNumber))) {
							notfound = false;
							break;
						}
					}
					if (notfound == true) {
						stripes.add(Integer.toString(stripNumber));
					}
					break;
				}

				stripNumber++;
			}
			/*
			 * Daniel Hijack the deleted blocks and delete from respective Disk servers
			 * splittedLine[0] is the disk number splittedLine[1] is the block number
			 */
			switch (String.valueOf(diskNumber)) {
			case "0":
				System.out.println("remove from Disk0");
				transferManagers.get(0).deleteFile(String.valueOf(blockNumber));
				break;
			case "1":
				transferManagers.get(1).deleteFile(String.valueOf(blockNumber));
				break;
			case "2":
				transferManagers.get(2).deleteFile(String.valueOf(blockNumber));
				break;
			case "3":
				transferManagers.get(3).deleteFile(String.valueOf(blockNumber));
				break;
			case "4":
				transferManagers.get(4).deleteFile(String.valueOf(blockNumber));
				break;
			default:

				break;
			}
		}
		// ParityManager pm = new ParityManager(rm);
		// pm.removeUnusedParity();

		rm.printBlockTableFirstTwoStrip();
		return stripes;
	}
}
