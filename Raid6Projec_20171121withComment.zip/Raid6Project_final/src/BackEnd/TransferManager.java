package BackEnd;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;

public class TransferManager {
	Socket ClientSoc;
	DataInputStream din;
	DataOutputStream dout;
	BufferedReader br;

	public TransferManager(String ipAdd, int port) {
		try {
			// create connection and data stream
			Socket soc = new Socket(ipAdd, port);
			ClientSoc = soc;
			din = new DataInputStream(ClientSoc.getInputStream());
			dout = new DataOutputStream(ClientSoc.getOutputStream());
			//br = new BufferedReader(new InputStreamReader(System.in));
		} catch (Exception ex) {
		}
	}

	public void exit() {
		try {
			dout.writeUTF("EXIT");
		} catch (Exception e) {
		}
	}

	//delete files on file system
	public void deleteFile(String fileName)
    {
    	try {
    		dout.writeUTF("DEL");
    		dout.writeUTF(fileName);
    		String msgFromServer = din.readUTF();
    		if (msgFromServer.compareTo("File Not Found") == 0) {
				System.out.println("File not found on remote disk ...");
				return;
    		} else if (msgFromServer.compareTo("DELETED") == 0) {
    			System.out.println("File Deleted ...");
    		}
    		
    	}catch (Exception e) {
			e.printStackTrace();
		}
  
    }

	//send files to file system
	public void sendFile(String fileName, String location) {
		try {
			// pass in send command
			dout.writeUTF("SEND");
			// create new file
			File f = new File(location);
			if (!f.exists()) {
				System.out.println("File not found...");
				dout.writeUTF("File not found");
				return;
			}

			dout.writeUTF(fileName);
			System.out.println("filename: " + fileName);
			String msgFromServer = din.readUTF();
			System.out.println(msgFromServer);
			// set always overwrite
			if (msgFromServer.compareTo("File Already Exists") == 0) {
				dout.writeUTF("Y");
			}

			System.out.println("Sending File ...");
			// send file
			FileInputStream fin = new FileInputStream(location);
			int ch;
			do {
				// System.out.println("reading file");
				ch = fin.read();
				dout.writeUTF(String.valueOf(ch));
			} while (ch != -1);
			fin.close();
			System.out.println(din.readUTF());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	//receive file from file system
	public boolean receiveFile(String fileName, String diskNo) throws Exception {
		try {
			// pass in receive command
			dout.writeUTF("GET");
			dout.writeUTF(fileName);
			System.out.println("File name is "+ fileName +"from server "+diskNo);
			String msgFromServer = din.readUTF();
			// Create receiving folder for each disk.
			File dir = new File("./tempDisk" + diskNo);
			if (!dir.exists()) {
				dir.mkdir();
			}

			// check if requested file in server
			if (msgFromServer.compareTo("File Not Found") == 0) {
				System.out.println("File not found on Server ...");
				return false;
			} else if (msgFromServer.compareTo("READY") == 0) {
				// start receiving
				System.out.println("Receiving File ...");
				File f = new File("./tempDisk"+diskNo+"/"+fileName);
				FileOutputStream fout = new FileOutputStream(f);
				int ch;
				String temp;
				do {
					temp = din.readUTF();
					ch = Integer.parseInt(temp);
					if (ch != -1) {
						fout.write(ch);
					}
				} while (ch != -1);
				fout.close();
				System.out.println(din.readUTF());
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return true;
	}

}
