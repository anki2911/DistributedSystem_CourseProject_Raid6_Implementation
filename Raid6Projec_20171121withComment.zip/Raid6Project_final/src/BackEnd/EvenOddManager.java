package BackEnd;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class EvenOddManager {
	private RaidManager rm;
	
	public EvenOddManager(RaidManager rm){
		this.rm = rm;
	}
	public static void main(String[] args) {
		//System.out.println(getSmallestPrime(1));
		//System.out.println(getCongruence(-2, 5));
		//m is the number of information disks
		
	}
	
	//remember, array is pass by reference!
	
	
	//calculate horizontal parity for evenodd coding scheme
	public ArrayList<byte[]> getHorizontalParity() throws IOException {
		int maxStrip = rm.getnumofStripswithInfo();
		int currentStrip=0;
		int blockSize = rm.getBlockSize();
		ArrayList<byte[]> stripBytes = new ArrayList();
		ArrayList<byte[]> horizontalParityList = new ArrayList<>();
		for(int[] strip:rm.getBlockTable()) {
			for(int i=0;i<strip.length;i++) {
				if(strip[i]==1) {
					Path path = Paths.get(rm.getDiskPath(i)+"/"+currentStrip);
					stripBytes.add(Files.readAllBytes(path));
				}else if(strip[i]==0) {
					byte[] emptyFile = new byte[blockSize];
					for(byte eachByte:emptyFile) {
						eachByte = (byte)0;
					}
					stripBytes.add(emptyFile);
				}
			}
			for(byte[] stripbytes:stripBytes) {
				for(int i=0;i<2;i++) {
					if(i==1)
					System.out.println("stripinfo for second byte: "+stripbytes[i]);
				}
			}
			byte[] horizontalParity = new byte[blockSize];
			for(byte b:horizontalParity) {
				b = (byte)0;
			}
			for(int i=0;i<blockSize;i++) {
				for(byte[] stripbytes:stripBytes) {
					if(i==1)
						System.out.println(horizontalParity[i]+"Xor"+stripbytes[i]);
					horizontalParity[i] = (byte)(horizontalParity[i]^stripbytes[i]);
				
//					if(i<10)
//					System.out.println("horizontalParity:"+(byte)horizontalParity[i]);
				}
				if(i<10)
					System.out.println("horizontalParity:"+horizontalParity[i]);
			}
			horizontalParityList.add(horizontalParity);
			stripBytes.clear();
			currentStrip++;
			if(currentStrip>=maxStrip) {
				break;
			}
			
		}
		System.out.println("horizontal parity number of strip: "+horizontalParityList.size());
		return horizontalParityList;		

	}
	
	//no need this method as the horizontal parity should calculate without dummy strip and disk.
//	public ArrayList<byte[]> getEvenOddHorizontalParity() throws IOException {
//		int currentStrip=0;
//		int maxStrip = rm.getnumofStripswithInfo();
//		int blockSize = rm.getBlockSize();
//		int[][] dummyBlockTable = makeDummyBlockTable();
//		ArrayList<byte[]> stripBytes = new ArrayList();
//		ArrayList<byte[]> horizontalParityList = new ArrayList<>();
//		for(int[] strip:dummyBlockTable) {
//			for(int i=0;i<strip.length;i++) {
//				if(strip[i]==1) {
//					Path path = Paths.get(rm.getDiskPath(i)+"/"+currentStrip);
//					stripBytes.add(Files.readAllBytes(path));
//				}else if(strip[i]==0) {
//					byte[] emptyFile = new byte[blockSize];
//					for(byte eachByte:emptyFile) {
//						eachByte = (byte)0;
//					}
//					stripBytes.add(emptyFile);
//				}
//			}
////			for(byte[] stripbytes:stripBytes) {
////				for(int i=0;i<2;i++) {
////					if(i==1)
////					System.out.println("stripinfo for second byte: "+stripbytes[i]);
////				}
////			}
//			byte[] horizontalParity = new byte[blockSize];
//			for(byte b:horizontalParity) {
//				b = (byte)0;
//			}
//			for(int i=0;i<blockSize;i++) {
//				for(byte[] stripbytes:stripBytes) {
//					if(i==1)
//						System.out.println(horizontalParity[i]+"Xor"+stripbytes[i]);
//					horizontalParity[i] = (byte)(horizontalParity[i]^stripbytes[i]);
//				
////					if(i<10)
////					System.out.println("horizontalParity:"+(byte)horizontalParity[i]);
//				}
//				if(i<10)
//					System.out.println("horizontalParity:"+horizontalParity[i]);
//			}
//			
//			horizontalParityList.add(horizontalParity);
//			
//			stripBytes.clear();
//			currentStrip++;
//			if(currentStrip>=maxStrip) {
//				break;
//			}
//			
//		}
//		System.out.println("horizontal parity number of strip: "+horizontalParityList.size());
//		return horizontalParityList;		
//
//	}
	
	
	
	//Calculate diagonal parity for evenodd coding scheme
	public byte[][] getDiagonalParity() throws Exception {
		int[][] blockTable = makeDummyBlockTable();
		ArrayList<int[]> realBlockTable = rm.getBlockTable();
		int maxStripwithInfo = rm.getnumofStripswithInfo();
		int realnumofDisk = rm.getnumofDisk();
		int m = blockTable[0].length-2;
		byte[] S = getS(blockTable);
		int count = 0;
		int blockSize = rm.getBlockSize();
		int debug;
		byte[][] diagonalParityList = new byte[blockTable.length][blockSize];
		for(int l=0;l<blockTable.length;l++) {
			ArrayList<byte[]> contentList = new ArrayList<>();
			byte[] parity = S.clone();
			for(int t=0;t<=m-1;t++) {
				System.out.println(getCongruence(l-t,m)+","+t);
				
				//if the block is dummy, all bytes are 0, no need used for calculation
				if(((getCongruence(l-t,m))<maxStripwithInfo)&&(t<realnumofDisk-2)) {
					System.out.println(getCongruence(l-t,m)+","+t);
					//shift blocks to get the needed one if the parity is stored in front.
					if(blockTable[getCongruence(l-t,m)][0]==3) {//if 3 at first, the one I want has been shift one.
						byte[] content;
						if(blockTable[getCongruence(l-t,m)][t+1]==1) {
						
						Path path = Paths.get(rm.getDiskPath(t+1)+"/"+getCongruence(l-t,m));	
						if(l==0) {
							System.out.println(rm.getDiskPath(t+1)+"/"+getCongruence(l-t,m));
						}
						content = Files.readAllBytes(path);
						}else{
							if(l==0) {
								System.out.println(rm.getDiskPath(t+1)+"/"+getCongruence(l-t,m));
							}
							content = new byte[blockSize];
							for(byte b:content) {
								b=(byte)0;
							}
						}
						contentList.add(content);
					}else if(parityInFront(blockTable[getCongruence(l-t,m)], t)) {//if 2 and 3 infront, need to shift 2 position
						byte[] content;
						if(blockTable[getCongruence(l-t,m)][t+2]==1) {		
						Path path = Paths.get(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));	
						if(l==0) {
							System.out.println(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
						}
						content = Files.readAllBytes(path);}else {
							if(l==0) {
								System.out.println(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
							}
							content = new byte[blockSize];
							for(byte b:content) {
								b=(byte)0;
							}
						}
						contentList.add(content);
					}else if(blockTable[getCongruence(l-t,m)][t]==2) {
						byte[] content;
					if(blockTable[getCongruence(l-t,m)][t+2]==1) {
						Path path = Paths.get(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));	
						if(l==0) {
							System.out.println(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
						}
						content = Files.readAllBytes(path);
					}else {
						if(l==0) {
							System.out.println(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
						}
						content = new byte[blockSize];
						for(byte b:content) {
							b=(byte)0;
						}
					}
					contentList.add(content);
					}else if(blockTable[getCongruence(l-t,m)][t]==1) {
						byte[] content;
						Path path = Paths.get(rm.getDiskPath(t)+"/"+getCongruence(l-t,m));	
						if(l==0) {
							System.out.println(rm.getDiskPath(t)+"/"+getCongruence(l-t,m));
						}
						content = Files.readAllBytes(path);
						contentList.add(content);
					}else if(blockTable[getCongruence(l-t,m)][t]==0) {
						if(l==0) {
							System.out.println(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
						}
						byte[] content = new byte[blockSize];
						for(byte b:content) {
							b=(byte)0;
						}
						contentList.add(content);
					}
						
						
						
						
						
//						else {
//						Path path = Paths.get(rm.getDiskPath(t)+"/"+getCongruence(l-t,m));
//						if(l==0) {
//							System.out.println(rm.getDiskPath(t)+"/"+getCongruence(l-t,m));
//						}
//						byte[] content = Files.readAllBytes(path);
//						contentList.add(content);
//					}
//				}else if(blockTable[getCongruence(l-t,m)][t]==2) {
//					Path path = Paths.get(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));	
//					File f = new File(path.toAbsolutePath().toString());
//					if(l==0) {
//						System.out.println(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
//					}
//					byte[] content;
//					if(f.exists()) {
//					content = Files.readAllBytes(path);
//					}else {
//						content = new byte[blockSize];
//						for(byte b:content) {
//							b=(byte)0;
//						}
//					}
//					contentList.add(content);
//				}else if(blockTable[getCongruence(l-t,m)][t]==3) {
//					if(blockTable[getCongruence(l-t,m)][0]==3) {
//						Path path = Paths.get(rm.getDiskPath(t+1)+"/"+getCongruence(l-t,m));	
//						if(l==0) {
//							System.out.println(rm.getDiskPath(t+1)+"/"+getCongruence(l-t,m));
//						}
//						File f = new File(path.toAbsolutePath().toString());
//						byte[] content;
//						if(f.exists()) {
//						content = Files.readAllBytes(path);}
//						else {
//							content = new byte[blockSize];
//							for(byte b:content) {
//								b=(byte)0;
//							}
//						}
//						contentList.add(content);
//					}else {
//					Path path = Paths.get(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
//					File f = new File(path.toAbsolutePath().toString());
//					if(l==0) {
//						System.out.println(rm.getDiskPath(t+2)+"/"+getCongruence(l-t,m));
//					}
//					byte[] content;
//					if(f.exists()) {
//					content = Files.readAllBytes(path);}
//					else {
//						content = new byte[blockSize];
//						for(byte b:content) {
//							b=(byte)0;
//						}
//					}
//					contentList.add(content);
//					}
//				}else if(blockTable[getCongruence(l-t,m)][t]==0) {
//					byte[] content = new byte[blockSize];
//					if(l==0) {
//						if(parityInFront(blockTable[getCongruence(l-t,m)],t)) {
//							if(blockTable[getCongruence(l-t,m)][0]==3) {
//								System.out.println(t+1+"/"+getCongruence(l-t,m));
//							}else {
//								System.out.println(t+2+"/"+getCongruence(l-t,m));
//							}
//						}else {
//						System.out.println(t+"/"+getCongruence(l-t,m));
//						}
//					}
//					for(byte b:content) {
//						b=(byte)0;
//					}
//					contentList.add(content);
//				}
//				
//				}
//			}
			//System.out.println(contentList.size());
				}}
			if(contentList.size()!=0) {
			for(byte[] content:contentList) {
				for(int i=0;i<blockSize;i++) {
					//System.out.println("Xor");
					parity[i] = (byte) (parity[i]^content[i]);
				}
			}}
			System.out.println("getDiagonal parity"+count);
			count++;
			diagonalParityList[l]=parity;
		}
		System.out.println("diagonal Parity 0:");
		for(byte b:diagonalParityList[0]) {
			System.out.print(b);
		}
		System.out.println();
		return diagonalParityList;
	}
	
	//get value S that used for evenodd coding scheme
	public byte[] getS(int[][] blockTable) throws Exception {
		int m = blockTable[0].length-2;
		int blockSize = rm.getBlockSize();
		int maxStripwithInfo = rm.getnumofStripswithInfo();
		int realDiskNumber = rm.getnumofDisk();
		ArrayList<byte[]> Scomponents = new ArrayList();
		for(int t=1;t<=m-1;t++) {
			if(t<realDiskNumber-2) {
				if(blockTable[m-1-t][0]==3) {//if 3 at first, the one I want has been shift one.
					byte[] content;
					if(blockTable[m-1-t][t+1]==1) {
					
					Path path = Paths.get(rm.getDiskPath(t+1)+"/"+(m-1-t));	
				
						System.out.println(rm.getDiskPath(t+1)+"/"+(m-1-t));
					
					content = Files.readAllBytes(path);
					}else{				
							System.out.println(rm.getDiskPath(t+1)+"/"+(m-1-t));						
						content = new byte[blockSize];
						for(byte b:content) {
							b=(byte)0;
						}
					}
					Scomponents.add(content);
				}else if(parityInFront(blockTable[m-1-t], t)) {//if 2 and 3 infront, need to shift 2 position
					byte[] content;
					if(blockTable[m-1-t][t+2]==1) {		
					Path path = Paths.get(rm.getDiskPath(t+2)+"/"+(m-1-t));	
				
						System.out.println(rm.getDiskPath(t+2)+"/"+(m-1-t));
					
					content = Files.readAllBytes(path);}else {
					
							System.out.println(rm.getDiskPath(t+2)+"/"+(m-1-t));
						
						content = new byte[blockSize];
						for(byte b:content) {
							b=(byte)0;
						}
					}
					Scomponents.add(content);
				}else if(blockTable[m-1-t][t]==2) {
					byte[] content;
				if(blockTable[m-1-t][t+2]==1) {
					Path path = Paths.get(rm.getDiskPath(t+2)+"/"+(m-1-t));	
				
						System.out.println(rm.getDiskPath(t+2)+"/"+(m-1-t));
					
					content = Files.readAllBytes(path);
				}else {
				
						System.out.println(rm.getDiskPath(t+2)+"/"+(m-1-t));
					
					content = new byte[blockSize];
					for(byte b:content) {
						b=(byte)0;
					}
				}
				Scomponents.add(content);
				}else if(blockTable[m-1-t][t]==1) {
					byte[] content;
					Path path = Paths.get(rm.getDiskPath(t)+"/"+(m-1-t));	
					
						System.out.println(rm.getDiskPath(t)+"/"+(m-1-t));
					
					content = Files.readAllBytes(path);
					Scomponents.add(content);
				}else if(blockTable[m-1-t][t]==0) {
				
						System.out.println(rm.getDiskPath(t+2)+"/"+(m-1-t));
					
					byte[] content = new byte[blockSize];
					for(byte b:content) {
						b=(byte)0;
					}
					Scomponents.add(content);
				}
			}
		}
			
			
			
//			if(blockTable[m-1-t][t]==1) {
//				if(blockTable[m-1-t][0]==3) {//if 3 at first, the one I want has been shift one.
//					Path path = Paths.get(rm.getDiskPath(t+1)+"/"+(m-1-t));				
//					byte[] content = Files.readAllBytes(path);
//					Scomponents.add(content);
//				}else if(parityInFront(blockTable[m-1-t], t)) {//if 2 and 3 infront, need to shift 2 position
//					Path path = Paths.get(rm.getDiskPath(t+2)+"/"+(m-1-t));				
//					byte[] content = Files.readAllBytes(path);
//					Scomponents.add(content);
//				}else {
//					Path path = Paths.get(rm.getDiskPath(t)+"/"+(m-1-t));				
//					byte[] content = Files.readAllBytes(path);
//					Scomponents.add(content);
//				}
//			}else if(blockTable[m-1-t][t]==2) {
//				Path path = Paths.get(rm.getDiskPath(t+2)+"/"+(m-1-t));
//				File f = new File(path.toAbsolutePath().toString());
//				byte[] content;
//				if(f.exists()) {
//				content = Files.readAllBytes(path);
//				}else {
//					content = new byte[blockSize];
//					for(byte b:content) {
//						b=(byte)0;
//					}
//				}
//				Scomponents.add(content);
//			}else if(blockTable[m-1-t][t]==3) {
//				if(blockTable[m-1-t][0]==3) {
//					Path path = Paths.get(rm.getDiskPath(t+1)+"/"+(m-1-t));
//					File f = new File(path.toAbsolutePath().toString());
//					byte[] content;
//					if(f.exists()) {
//					content = Files.readAllBytes(path);}
//					else {
//						content = new byte[blockSize];
//						for(byte b:content) {
//							b=(byte)0;
//						}
//					}
//					Scomponents.add(content);
//				}else {
//				Path path = Paths.get(rm.getDiskPath(t+2)+"/"+(m-1-t));	
//				File f = new File(path.toAbsolutePath().toString());
//				byte[] content;
//				if(f.exists()) {
//				content = Files.readAllBytes(path);}
//				else {
//					content = new byte[blockSize];
//					for(byte b:content) {
//						b=(byte)0;
//					}
//				}
//				Scomponents.add(content);
//				}
//			}else if(blockTable[m-1-t][t]==0) {
//				byte[] content = new byte[blockSize];
//				for(byte b:content) {
//					b=(byte)0;
//				}
//				Scomponents.add(content);
//			}
//		}
		byte[] S = new byte[blockSize];
		for(byte b:S) {
			b=(byte)0;
		}
		if(Scomponents.size()!=0) {
			for(int i=0;i<blockSize;i++) {
				for(byte[] content:Scomponents) {
					S[i] = (byte)(S[i]^content[i]);
				
				}
			}}
//			if(true) {
//				throw new Exception("getS successfully!");
//			}
		System.out.println("S:");
		for(byte b:S) {
			System.out.print(b);
		}
		System.out.println();
			return S;
			
		
	}
	
	
	//check whether there is parity block stored in front of current block in the same strip
	public boolean parityInFront(int[] strip,int position) {
		boolean parityInfront = false;
		for(int b=0;b<position;b++) {
			if((strip[b]==2)||(strip[b]==3)) {
				parityInfront = true;
			}
		}
		return parityInfront;
	}
	
	//get Congruence value in formula
	public static int getCongruence(double n,double m) {
		int j = 0;
		while(j<m) {
			if((n-j)%m==0) {
				break;
			}
			j++;
		}
		return j;
	}
	
	//get the smallest prime number that is larger than current number of disks or block size
	public static int getSmallestPrime(int n) {
		while(n>0) {
			if(isPrime(n)) {
				break;
			}
			n++;
		}
		return n;
	}
	
	//check whether the number is a prime
	public static boolean isPrime(int n) {
		if(n==2) return true;
	    //check if n is a multiple of 2
	    if (n%2==0) return false;
	    //if not, then just check the odds
	    for(int i=3;i*i<=n;i+=2) {
	        if(n%i==0)
	            return false;
	    }
	    return true;
	}
	
	//make the dummy table that the number of information disks is a prime number
	public int[][] makeDummyBlockTable() {
		ArrayList<int[]> blockTable = rm.getBlockTable();
		int[][] dummyBlockTable;
		if(blockTable.size()>=blockTable.get(0).length-2) {
			dummyBlockTable = new int[getSmallestPrime(blockTable.size()+1)-1][getSmallestPrime(blockTable.size()+1)+2];
			
		}else {
			dummyBlockTable = new int[getSmallestPrime(blockTable.get(0).length-2)-1][getSmallestPrime(blockTable.get(0).length-2)+2];
		}
		System.out.println("DummyBlockTable with size:"+ dummyBlockTable.length+"*"+dummyBlockTable[0].length);	
		for(int i=0;i<dummyBlockTable.length;i++) {
			for(int j=0;j<dummyBlockTable[0].length;j++) {
				if(i<blockTable.size()&&j<blockTable.get(0).length) {
				dummyBlockTable[i][j]=blockTable.get(i)[j];
				}else {
					dummyBlockTable[i][j]=0;
				}
			}
		}
		for(int i=0;i<dummyBlockTable.length;i++) {
			for(int j=0;j<dummyBlockTable[0].length;j++) {
		System.out.print(dummyBlockTable[i][j]);
			}
			System.out.println();
		}
		return dummyBlockTable;
	}
	
	
	
	

}



