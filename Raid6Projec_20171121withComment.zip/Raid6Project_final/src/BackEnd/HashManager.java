package BackEnd;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.xml.bind.DatatypeConverter;

public class HashManager {

	

	//generate the hashing value for a block
	public String hashString(byte[] data) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(data);
		byte[] thedigest = md.digest();
		return DatatypeConverter.printHexBinary(thedigest).toUpperCase();
	}
}
