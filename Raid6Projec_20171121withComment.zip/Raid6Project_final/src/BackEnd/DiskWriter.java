package BackEnd;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;

public class DiskWriter {
	private RaidManager rm;
	private ParityManager pm;
	private TransferManager tm0;
	private TransferManager tm1;
	private TransferManager tm2;
	private TransferManager tm3;
	private TransferManager tm4;

	
	public DiskWriter(RaidManager rm) {
		this.rm = rm;
	}

	public DiskWriter(RaidManager rm, ParityManager pm) {
		this.rm = rm;
		this.pm = pm;
	}

	// initialize disk writer with transfer manager to send data to file system.
	public DiskWriter(RaidManager rm, ParityManager pm, ArrayList<TransferManager> transferManagers) {
		this.rm = rm;
		this.pm = pm;
		this.tm0 = transferManagers.get(0);
		this.tm1 = transferManagers.get(1);
		this.tm2 = transferManagers.get(2);
		this.tm3 = transferManagers.get(3);
		this.tm4 = transferManagers.get(4);
	}

	//write the uploaded file to physical disks.
	public void writeToDisk(java.io.File file) throws IOException, NumberFormatException, NoSuchAlgorithmException {
		String Strpath = file.getPath();
		Path path = Paths.get(Strpath);
		// readAllBytes: LIMIT OF 2GB
		byte[] data = Files.readAllBytes(path);
		int numofBlocks = 0;
		double blockSize = rm.getBlockSize();
		ArrayList<String> StripeList = new ArrayList();
		System.out.println("file size: " + data.length + " bytes");
		numofBlocks = (int) Math.ceil(data.length / blockSize);
		System.out.println(data.length + "/" + blockSize);
		System.out.println(numofBlocks + " Blocks required");
		if (rm.getfreeBlocks() >= numofBlocks) {
			ArrayList<String> availableBlockList = rm.getAvailableBlocks(numofBlocks);
			// System.out.println("block table size:"+rm.getBlockTable().size());
			for (String s : availableBlockList) {
				System.out.println("available block: " + s);
			}
			writeToBlock(file, data, (int) blockSize, availableBlockList);
			System.out.println("File write successfully!");
			// rm.printBlockTableStrip();
			StripeList = findStripes(availableBlockList, rm.getnumofDisk());
			calculateParity(StripeList);
			System.out.println("Parity Calculation done");
		} else {
			System.out.println("File cannot be allocated due to shortage of space");
		}
		// avaiableBlockList format [disk, blockno]
		// writeToBlock(file, data, (int) blockSize, availableBlockList);
		System.out.println("Local File write success!");
		// rm.printBlockTableFirstTwoStrip();
		rm.printBlockTableV2();

	}

	//Find stripes
	public ArrayList<String> findStripes(ArrayList<String> stripeList, int num) {
		ArrayList<String> Stripes = new ArrayList();

		for (String blockno : stripeList) {
			String[] splittedLine = blockno.split(",");
			String stripeno = splittedLine[1];
			if (!Stripes.contains(stripeno)) {
				Stripes.add(stripeno);
			}
		}
		return Stripes;
	}

	//Write the chunks of the file to corresponding physical blocks in disks
	public void writeToBlock(java.io.File file, byte[] data, int blockSize, ArrayList<String> availableBlockList)
			throws NumberFormatException, IOException, NoSuchAlgorithmException {
		int writeStartPostion = 0;
		int currentWritePostion = 0;
		byte[] blockContent = new byte[rm.getBlockSize()];
		HashMap<String, String> HashofBlocks = new HashMap<>();
		HashManager hm = new HashManager();
		for (byte b : data) {
			System.out.print(Byte.toString(b));
		}
		System.out.println("\n");
		for (String blockLocation : availableBlockList) {
			byte[] currentBlockBytes = new byte[blockSize];
			String[] splittedLine = blockLocation.split(",");
			String storeLocation = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
			System.out.println("storeLocation: " + storeLocation);
			FileOutputStream out = new FileOutputStream(storeLocation);
			for (int i = writeStartPostion; i < writeStartPostion + blockSize; i++) {
				currentWritePostion = i;
				if (currentWritePostion >= data.length) {
					currentBlockBytes[i - writeStartPostion] = (byte) 0;
				} else {
					currentBlockBytes[i - writeStartPostion] = data[i];
				}
			}
			out.write(currentBlockBytes);

			// System.out.println("HashValue:" + hm.hashString(currentBlockBytes));
			HashofBlocks.put(blockLocation, hm.hashString(currentBlockBytes));
			rm.setBlockOccupied(blockLocation);
			writeStartPostion = currentWritePostion + 1;
			out.close();
			/*
			 * Daniel Hijack the out file and send to respective Disk servers
			 * splittedLine[0] is the disk number splittedLine[1] is the block number
			 */
			switch (splittedLine[0]) {
			case "0":
				System.out.println("Sending Data to Disk 0 Server");
				tm0.sendFile(splittedLine[1], storeLocation);
				break;
			case "1":
				System.out.println("Sending Data to Disk 1 Server");
				tm1.sendFile(splittedLine[1], storeLocation);
				break;
			case "2":
				System.out.println("Sending Data to Disk 2 Server");
				tm2.sendFile(splittedLine[1], storeLocation);
				break;
			case "3":
				System.out.println("Sending Data to Disk 3 Server");
				tm3.sendFile(splittedLine[1], storeLocation);
				break;
			case "4":
				System.out.println("Sending Data to Disk 4 Server");
				tm4.sendFile(splittedLine[1], storeLocation);
				break;
			default:

				break;
			}
		}
		updateMasterInfo(file, availableBlockList, HashofBlocks, data);
	}

	//update Master Info file after changes in file system.
	public void updateMasterInfo(java.io.File file, ArrayList<String> availableBlockList,
			HashMap<String, String> HashofBlocks, byte[] data) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(rm.MASTERINFOFILE, true));
		bw.write(file.getName() + ";" + data.length + ";\n");
		for (String blockLocation : availableBlockList) {
			String[] splittedLine = blockLocation.split(",");
			bw.write("D" + splittedLine[0] + "B" + splittedLine[1] + ";");
			bw.write(HashofBlocks.get(blockLocation) + ";");
		}
		bw.write("\n");
		bw.close();

	}

	//Calculate the parities
	public void calculateParity(ArrayList<String> stripeList) throws IOException {
		int numofDisk = rm.getnumofDisk();
		int blockSize = rm.getBlockSize();
		int posparity1 = 0;
		int posparity2 = 0;
		HashMap<String, String> HashofBlocks1 = new HashMap<>();
		HashManager hm1 = new HashManager();
		HashMap<String, String> HashofBlocks2 = new HashMap<>();
		HashManager hm2 = new HashManager();
		byte[] ParityBlock1 = new byte[blockSize];
		byte[] ParityBlock2 = new byte[blockSize];

		for (String i : stripeList) {
			int stripeno = Integer.parseInt(i);
			int counter = 0;
			for (int[] blk : rm.BlockTable) {
				if (counter == stripeno) {
					ArrayList<String> blockList = new ArrayList();
					for (int j = 0; j < numofDisk; j++) {
						if (blk[j] == 2) {
							posparity1 = j;
						}
						if (blk[j] == 3) {
							posparity2 = j;
						}
						if (blk[j] == 1) {
							blockList.add(Integer.toString(j));
						}
					}
					try {
						if (blockList.size() > 0) {
							ParityBlock1 = calculate_parity1(numofDisk, posparity1, stripeno, blockList);
							String stripstoreLocation1 = "D" + posparity1 + "p" + stripeno;
							String hashedVal1 = hm1.hashString(ParityBlock1);
							ParityBlock2 = calculate_parity2(numofDisk, posparity2, stripeno, blockList);
							String stripstoreLocation2 = "D" + posparity2 + "q" + stripeno;
							String hashedVal2 = hm2.hashString(ParityBlock2);
							writeParityInfo(hashedVal1, stripstoreLocation1, hashedVal2, stripstoreLocation2);
						}

					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				counter++;
			}

		}
	}

	//Write Parity Info file
	private void writeParityInfo(String hVal1, String location1, String hVal2, String location2) throws IOException {
		// TODO Auto-generated method stub
		File originalFile = new File(rm.getParityInfo());
		File tempFile = new File(rm.getParityInfo() + "tmp");
		BufferedReader bf = new BufferedReader(new FileReader(originalFile));
		BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
		String line = "";
		boolean found = false;
		while ((line = bf.readLine()) != null) {
			String[] splittedLine = line.split(";");
			if (!splittedLine[0].equals(location1)) {
				bw.write(
						splittedLine[0] + ";" + splittedLine[1] + ";" + splittedLine[2] + ";" + splittedLine[3] + "\n");
			}
		}
		bw.write(location1 + ";" + hVal1 + ";" + location2 + ";" + hVal2 + ";" + "\n");
		bw.close();
		bf.close();
		System.out.println("writeParityInfo");

		String fileName = "ParityInfo.txt";
		File folder = new File("./src/MainInterface/");
		File[] directoryListing = folder.listFiles();
		if (directoryListing != null) {
			for (File file : directoryListing) {
				if (file.getName().equals("ParityInfo.txt")) {

					file.delete();
				}
			}

		}
		tempFile.renameTo(originalFile);
	}

	//update all Parities
	public void updateAllParity() throws IOException {
		// TODO Auto-generated method stub
		ArrayList<byte[]> Plist = new ArrayList();
		ArrayList<byte[]> Qlist = new ArrayList();
		ArrayList<String> Hlist1 = new ArrayList();
		ArrayList<String> Hlist2 = new ArrayList();
		ArrayList<String> listofstripes = new ArrayList();
		int posparity1 = -1;
		int posparity2 = -1;
		int blockSize = rm.getBlockSize();
		int numofDisk = rm.getnumofDisk();
		byte[] ParityBlock1 = new byte[blockSize];
		byte[] ParityBlock2 = new byte[blockSize];
		int count = 0;
		for (int[] strip : rm.BlockTable) {
			boolean found = false;
			for (int j = 0; j < rm.getnumofDisk(); j++) {
				if (strip[j] == 1) {
					found = true;
					listofstripes.add(Integer.toString(count));
					break;
				}
			}
			count++;
		}

		for (String i : listofstripes) {
			int stripeno = Integer.parseInt(i);
			int counter = 0;
			for (int[] blk : rm.BlockTable) {
				if (counter == stripeno) {
					ArrayList<String> blockList = new ArrayList();
					for (int j = 0; j < rm.getnumofDisk(); j++) {
						if (blk[j] == 2) {
							posparity1 = j;
						}
						if (blk[j] == 3) {
							posparity2 = j;
						}
						if (blk[j] == 1) {
							blockList.add(Integer.toString(j));
						}
					}
					try {
						if (blockList.size() > 0) {
							ParityBlock1 = calculate_parity1(numofDisk, posparity1, stripeno, blockList);
							String stripstoreLocation1 = "D" + posparity1 + "p" + stripeno;
							HashManager hm1 = new HashManager();
							String hashedVal1 = hm1.hashString(ParityBlock1);
							ParityBlock2 = calculate_parity2(numofDisk, posparity2, stripeno, blockList);
							String stripstoreLocation2 = "D" + posparity2 + "q" + stripeno;
							HashManager hm2 = new HashManager();
							String hashedVal2 = hm2.hashString(ParityBlock2);
							Plist.add(ParityBlock1);
							Hlist1.add(hashedVal1);
							Qlist.add(ParityBlock2);
							Hlist2.add(hashedVal2);
						}

					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				counter++;
			}

		}
		// File originalFile = new File(rm.getParityInfo());
		File tempFile = new File(rm.getParityInfo() + "tmp");
		BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
		for (int i = 0; i < Plist.size(); i++) {
			bw.write(Plist.get(i) + ";" + Hlist1.get(i) + ";" + Qlist.get(i) + ";" + Hlist2.get(i) + ";" + "\n");
		}
		bw.close();
		
		//update Parity Info file
		String fileName = "ParityInfo.txt";
		File folder = new File("./src/MainInterface/");
		File[] directoryListing = folder.listFiles();
		if (directoryListing != null) {
			for (File file : directoryListing) {

				if (file.getName().equals("ParityInfo.txt")) {

					file.delete();
				}
			}

		}
		tempFile.renameTo(new File(fileName));
		// originalFile.delete();
		// tempFile.renameTo(originalFile);
	}

	// Calculate the P parity
	public byte[] calculate_parity1(int numofDisk, int DiskNo, int stripeno, ArrayList<String> datablockList)
			throws IOException, NoSuchAlgorithmException {
		String stripestoreLocation = rm.getDiskPath(DiskNo) + "/p" + stripeno;
		// System.out.println(stripestoreLocation);
		// System.out.println(DiskNo);
		// System.out.println(stripeno);
		int blockSize = rm.getBlockSize();
		byte[][] dataBlock = new byte[numofDisk - 2][blockSize];
		int k = 0;
		int posq = (DiskNo + 1) % numofDisk;
		for (int i = 0; i < numofDisk; i++) {

			if (datablockList.contains(Integer.toString(i))) {
				String Strpath = rm.getDiskPath(i) + "/" + stripeno;
				Path path = Paths.get(Strpath);
				byte[] data = Files.readAllBytes(path);
				dataBlock[k] = data;
				k++;
			} else if (i != DiskNo && i != posq) {
				for (int j = 0; j < blockSize; j++) {
					dataBlock[k][j] = (byte) 0;
				}
				k++;

			}
		}
		byte[] parityBlock1 = new byte[blockSize];
		parityBlock1 = pm.calculatePblock(numofDisk - 2, dataBlock, blockSize);
		FileOutputStream fileOutputStream = new FileOutputStream(stripestoreLocation);
		fileOutputStream.write(parityBlock1);
		fileOutputStream.close();
		System.out.println(
				"Parity 1 Generated in disk " + DiskNo + " location" + stripestoreLocation + " Stripe " + stripeno);
		// Upload p parity to respective disk server
		switch (DiskNo) {
		case 0:
			System.out.println("Sending p-parity to Disk 0 Server");
			tm0.sendFile("p" + stripeno, stripestoreLocation);
			break;
		case 1:
			System.out.println("Sending p-parity to Disk 1 Server");
			tm1.sendFile("p" + stripeno, stripestoreLocation);
			break;
		case 2:
			System.out.println("Sending p-parity to Disk 2 Server");
			tm2.sendFile("p" + stripeno, stripestoreLocation);
			// tm2.sendFile(splittedLine[1], storeLocation);
			break;
		case 3:
			System.out.println("Sending p-parity to Disk 3 Server");
			tm3.sendFile("p" + stripeno, stripestoreLocation);
			// tm3.sendFile(splittedLine[1], storeLocation);
			break;
		case 4:
			System.out.println("Sending p-parity to Disk 4 Server");
			tm4.sendFile("p" + stripeno, stripestoreLocation);
			// tm4.sendFile(splittedLine[1], storeLocation);
			break;
		default:
			System.out.println("inside default.");
			break;
		}
		return parityBlock1;
	}

	// Calculate the q parity
	public byte[] calculate_parity2(int numofDisk, int DiskNo, int stripeno, ArrayList<String> datablockList)
			throws IOException, NoSuchAlgorithmException {
		String stripestoreLocation = rm.getDiskPath(DiskNo) + "/q" + stripeno;
		int blockSize = rm.getBlockSize();
		int posp = 0;
		byte[][] dataBlock = new byte[numofDisk - 2][blockSize];

		int k = 0;
		if (DiskNo == 0) {
			posp = numofDisk - 1;
		} else {
			posp = (DiskNo - 1) % numofDisk;
		}
		for (int i = 0; i < numofDisk; i++) {
			if (datablockList.contains(Integer.toString(i))) {
				String Strpath = rm.getDiskPath(i) + "/" + stripeno;
				Path path = Paths.get(Strpath);
				byte[] data = Files.readAllBytes(path);
				dataBlock[k] = data;
				k++;
			} else if (i != DiskNo && i != posp) {
				for (int j = 0; j < blockSize; j++) {
					dataBlock[k][j] = (byte) 0;
				}
				k++;

			}
		}
		byte[] parityBlock2 = new byte[blockSize];
		parityBlock2 = pm.calculateQblock(datablockList.size(), dataBlock, blockSize);
		FileOutputStream fileOutputStream = new FileOutputStream(stripestoreLocation);
		fileOutputStream.write(parityBlock2);
		fileOutputStream.close();
		System.out.println("Parity 2 Generated");
		// Upload file to respective disk server
		switch (DiskNo) {
		case 0:
			System.out.println("Sending q-parity to Disk 0 Server");
			tm0.sendFile("q" + stripeno, stripestoreLocation);
			break;
		case 1:
			System.out.println("Sending q-parity to Disk 1 Server");
			tm1.sendFile("q" + stripeno, stripestoreLocation);
			// tm1.sendFile(splittedLine[1], storeLocation);
			break;
		case 2:
			System.out.println("Sending q-parity to Disk 2 Server");
			tm2.sendFile("q" + stripeno, stripestoreLocation);
			// tm2.sendFile(splittedLine[1], storeLocation);
			break;
		case 3:
			System.out.println("Sending q-parity to Disk 3 Server");
			tm3.sendFile("q" + stripeno, stripestoreLocation);
			// tm3.sendFile(splittedLine[1], storeLocation);
			break;
		case 4:
			System.out.println("Sending q-parity to Disk 4 Server");
			tm4.sendFile("q" + stripeno, stripestoreLocation);
			// tm4.sendFile(splittedLine[1], storeLocation);
			break;
		default:
			System.out.println("inside default.");
			break;
		}
		return parityBlock2;
	}

	//write the evenodd horizontal parity to disks
	public void writeEvenOddHorizontalParity() throws IOException {
		EvenOddManager eom = new EvenOddManager(rm);
		ArrayList<byte[]> horizontalParityList = eom.getHorizontalParity();
		int currentStrip = 0;
		for (int[] strip : rm.getBlockTable()) {
			for (int disk = 0; disk < strip.length; disk++) {
				if (strip[disk] == 2) {
					String location = rm.getDiskPath(disk) + "/" + "p" + currentStrip;
					FileOutputStream out = new FileOutputStream(location);
					out.write(horizontalParityList.get(currentStrip));
					System.out.println("write current strip horizontal parity:");
					for (byte b : horizontalParityList.get(currentStrip)) {
						System.out.print(b);
					}
					System.out.println();

				}
			}
			currentStrip++;
			if (currentStrip >= horizontalParityList.size()) {
				break;
			}
		}
		System.out.println("Horizontal Parity write successfully!");
	}

	
	//write evenodd diagonal parity to disks
	public void writeEvenOddDiagonalParity() throws Exception {
		int maxStripwithInfo = rm.getnumofStripswithInfo();
		EvenOddManager eom = new EvenOddManager(rm);
		ArrayList<int[]> blockTable = rm.getBlockTable();
		byte[][] diagonalParityList = eom.getDiagonalParity();
		for (int i = 0; i < maxStripwithInfo; i++) {
			System.out.println("write diagonal parity i=" + i);
			int[] strip = blockTable.get(i);
			for (int j = 0; j < strip.length; j++) {
				if (strip[j] == 3) {
					System.out.println("write diagonal parity strip" + i);
					FileOutputStream out = new FileOutputStream(rm.getDiskPath(j) + "/" + "q" + i);
					out.write(diagonalParityList[i]);
					out.close();
					System.out.println("write current strip diagonal parity:");
					for (byte b : diagonalParityList[i]) {
						System.out.print(b);
					}
					System.out.println();
					break;
				}
			}
		}

	}

}
