package BackEnd;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Arrays;
import java.util.HashMap;

public class RaidManager {

	// assume each disk is 16M = 16384KB = 16777216B
	static final String BLOCKSIZEFILE = "./src/MainInterface/BlockSizeByte.properties";
	static final String MASTERINFOFILE = "./src/MainInterface/MasterInfo.txt";
	static final String DISKCONFIGFILE = "./src/MainInterface/DiskConfig.properties";
	static final String PARITYINFOFILE = "./src/MainInterface/ParityInfo.txt";
	static final int DiskSize = 163840; // 160K // 16M - 16777216
	ArrayList<int[]> BlockTable = new ArrayList();
	// when it returns available block, it is in the format "disk,strip"
	private int numofBlockperDisk;
	private int numofDisk;
	private int freeBlocks = 0;

	//returns block size
	public int getBlockSize() throws IOException {
		Properties p = new Properties();
		InputStream is = new FileInputStream(BLOCKSIZEFILE);
		p.load(is);
		// System.out.println("Current Block Size: " +
		// Integer.parseInt(p.getProperty("BlockSize")) + " bytes");
		int blockSize = Integer.parseInt(p.getProperty("BlockSize"));
		is.close();
		return blockSize;
	}

	//returns number of disks
	public int getnumofDisk() throws IOException {
		Properties p = new Properties();
		InputStream is = new FileInputStream(DISKCONFIGFILE);
		p.load(is);
		// System.out.println("Current Number of Disk: " + p.getProperty("numofDisk"));
		int numofDisk = Integer.parseInt(p.getProperty("numofDisk"));
		is.close();
		return numofDisk;
	}

	//returns number of free blocks
	public int getfreeBlocks() {
		return freeBlocks;
	}

	//returns the arraylist contains the location of available blocks
	public ArrayList<String> getAvailableBlocks(int numofBlocks) {
		ArrayList<String> availableBlockList = new ArrayList<>();
		int strip = 0;
		freeBlocks -= numofBlocks;
		outerloop: for (int[] i : BlockTable) {
			for (int j = 0; j < numofDisk; j++) {
				if (i[j] == 0) {
					availableBlockList.add(j + "," + strip);
					numofBlocks--;
					if (numofBlocks == 0) {
						break outerloop;
					}
				}
			}
			strip++;
		}
		System.out.println("availableBlockList size:" + availableBlockList.size());

		return availableBlockList;
	}

	//reset the block table.
	public void resetBlockTable() throws IOException {
		int blockSize = getBlockSize();
		numofBlockperDisk = Math.floorDiv(DiskSize, blockSize);
		numofDisk = getnumofDisk();
		int r = 0;
		BlockTable.clear();
		for (int i = 0; i < numofBlockperDisk; i++) {
			BlockTable.add(new int[numofDisk]);
		}
		for (int[] strip : BlockTable) {

			for (int j = 0; j < numofDisk; j++) {
				if (j == (numofDisk - ((r) % (numofDisk)) - 1)) {
					strip[j] = 3; // 2 is parity p
				} else if (j == (numofDisk - ((r + 1) % (numofDisk))) - 1) {
					strip[j] = 2; // 3 is parity q
				} else {
					strip[j] = 0;
					freeBlocks += 1;
				}
			}
			r++;
		}
		System.out.println("Number of Disk" + numofDisk);
		System.out.println("Number of Blocks per Disk" + numofBlockperDisk);
		// for(int[] strip:BlockTable) {
		// System.out.println();
		// for(int i:strip) {
		// System.out.print(i+"\t");
		// }
		// }

	}

	//returns the physical path of the disk according to disk number
	public String getDiskPath(int diskNumber) throws IOException {
		Properties p = new Properties();
		InputStream is = new FileInputStream(DISKCONFIGFILE);
		p.load(is);
		String diskPath = p.getProperty("D" + diskNumber);
		is.close();
		return diskPath;
	}

	//returns the block table
	public ArrayList<int[]> getBlockTable() {
		return BlockTable;
	}

	//initial tmp disk that used for parity calculation
	public void initTmpDisk(int numofDisk) {
		File dir = new File("./");
		File[] directoryListing = dir.listFiles();

		// init tempDisks only
		if (directoryListing != null) {
			for (File folder : directoryListing) {
				if (folder.getName().length() >= 8) {
					if (folder.getName().substring(0, 8).equals("tempDisk")) {
						String[] entries = folder.list();
						for (String s : entries) {
							File currentFile = new File(folder.getPath(), s);
							currentFile.delete();
						}
						folder.delete();
					}
				}
			}
		}
		for (int i = 0; i < numofDisk; i++) {
			File disk = new File("./tempDisk" + i);
			if (!disk.exists()) {
				disk.mkdir();
			}
		}
		System.out.println("tempDisk reinitalised successfully");
	}

	//initial disks
	public void initDisk(int numofDisk) {
		File dir = new File("./");
		File[] directoryListing = dir.listFiles();
		if (directoryListing != null) {
			for (File folder : directoryListing) {
				if (folder.getName().length() >= 4) {
					if (folder.getName().substring(0, 4).equals("Disk")) {
						String[] entries = folder.list();
						for (String s : entries) {
							File currentFile = new File(folder.getPath(), s);
							currentFile.delete();
						}
						folder.delete();
					}
				}
			}
		}
		for (int i = 0; i < numofDisk; i++) {
			File disk = new File("./Disk" + i);
			if (!disk.exists()) {
				disk.mkdir();
			} else {
				// String[]entries = disk.list();
				// for(String s: entries){
				// File currentFile = new File(disk.getPath(),s);
				// currentFile.delete();
				// }
				// disk.delete();
				// disk.mkdir();
				throw new RuntimeException("Disk does not deleted before recreate");
			}
		}

		// Add init tempDisks
		if (directoryListing != null) {
			for (File folder : directoryListing) {
				if (folder.getName().length() >= 8) {
					if (folder.getName().substring(0, 8).equals("tempDisk")) {
						String[] entries = folder.list();
						for (String s : entries) {
							File currentFile = new File(folder.getPath(), s);
							currentFile.delete();
						}
						folder.delete();
					}
				}
			}
		}
		for (int i = 0; i < numofDisk; i++) {
			File disk = new File("./tempDisk" + i);
			if (!disk.exists()) {
				disk.mkdir();
			}
		}
		System.out.println("Disks & tempDisks init successfully");
	}

	//initial Master Info file
	public void initMasterInfo() throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(MASTERINFOFILE));
		bw.close();
	}

	//initial Parity Info file
	public void initParityInfo() throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(PARITYINFOFILE));
		bw.close();
	}

	//set the block to be occupied in block table
	public void setBlockOccupied(String blockLocation) {
		String[] splittedLine = blockLocation.split(",");
		int diskNumber = Integer.parseInt(splittedLine[0]);
		int stripNumber = Integer.parseInt(splittedLine[1]);
		int stripCounter = 0;
		for (int[] strip : BlockTable) {
			if (stripCounter == stripNumber) {
				strip[diskNumber] = 1;
			}
			stripCounter++;
		}
	}

	//print the block table
	public void printBlockTable() {
		for (int[] ia : BlockTable) {
			for (int i : ia) {
				System.out.print(i);
			}
			System.out.println();
		}
	}

	//print the block table
	public void printBlockTableV2() {
		for (int[] ia : BlockTable) {
			System.out.print(Arrays.toString(ia));
		}
		System.out.println();
	}
	//print the first two strip of block table, used for debugging
	public void printBlockTableFirstTwoStrip() {
		System.out.println("Print the state of first two strip:");
		int counter = 0;
		for (int[] ia : BlockTable) {
			for (int i : ia) {
				System.out.print(i);
			}
			System.out.println();
			if (counter == 5) {
				break;
			}
			counter++;

		}
	}
	
	//returns Master Info file
	public String getMasterInfo() {
		return MASTERINFOFILE;
	}

	//returns Parity Info file
	public String getParityInfo() {
		return PARITYINFOFILE;
	}

	//returns the content of the file in bytes
	public ArrayList<byte[]> getStoredFile(String fileName, ArrayList<TransferManager> transferManagers) throws Exception {
		ArrayList<byte[]> contentList = new ArrayList<>();
		BufferedReader bf = new BufferedReader(new FileReader(MASTERINFOFILE));
		String line = "";
		ArrayList<String> FileBlockLocation = getFileBlocksLocation(fileName);
		for (String s : FileBlockLocation) {
			System.out.println(s);
		}
		while ((line = bf.readLine()) != null) {

			String[] splittedLine = line.split(";");
			if (splittedLine[0].equals(fileName)) {
				line = bf.readLine();
				splittedLine = line.split(";");
				for (int i = 0; i < splittedLine.length; i += 2) {
					System.out.println("It stored at " + splittedLine[i]);
					String[] splittedLocation = splittedLine[i].split("B");
					// Obtain local copy
//					Path path = Paths.get(getDiskPath(
//							Integer.parseInt(splittedLocation[0].substring(1, splittedLocation[0].length()))) + "/"
//							+ splittedLocation[1]);
//					byte[] lines = Files.readAllBytes(path);
//					//byte data of the whole file
//					contentList.add(lines);
					// Obtain local copy
					
					//Obtain Server copy
					String diskNo = splittedLocation[0].substring(1, splittedLocation[0].length());
					switch (diskNo) {
					case "0":
						if (transferManagers.get(0).receiveFile(splittedLocation[1], diskNo) == true) {
							
							byte[] downloadline = Files
									.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
							contentList.add(downloadline);


						} else {
							System.out.println("File " + splittedLocation[1] + "not found on disk server" + diskNo);
						}

						break;
					case "1":
						// transferManagers.get(1).receiveFile(splittedLocation[1]);
						if (transferManagers.get(1).receiveFile(splittedLocation[1], diskNo) == true) {
							
							byte[] downloadline = Files
									.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
							contentList.add(downloadline);


						} else {
							System.out.println("File " + splittedLocation[1] + "not found on disk server" + diskNo);
						}
						
						break;
					case "2":
						// transferManagers.get(2).receiveFile(splittedLocation[1]);
						if (transferManagers.get(2).receiveFile(splittedLocation[1], diskNo) == true) {
							byte[] downloadline = Files
									.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
							contentList.add(downloadline);


						} else {
							System.out.println("File " + splittedLocation[1] + "not found on disk server" + diskNo);
						}
						
						break;
					case "3":
						// transferManagers.get(3).receiveFile(splittedLocation[1]);
						if (transferManagers.get(3).receiveFile(splittedLocation[1], diskNo) == true) {
							byte[] downloadline = Files
									.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
							contentList.add(downloadline);


						} else {
							System.out.println("File " + splittedLocation[1] + "not found on disk server" + diskNo);
						}
						
						break;
					case "4":
						// transferManagers.get(4).receiveFile(splittedLocation[1]);
						if (transferManagers.get(4).receiveFile(splittedLocation[1], diskNo) == true) {
							byte[] downloadline = Files
									.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
							contentList.add(downloadline);


						} else {
							System.out.println("File " + splittedLocation[1] + "not found on disk server" + diskNo);
						}
						break;
					default:

						break;
					}// end switch
	

				}
				break;
			}

		}bf.close();return contentList;

	}

	//returns the blocks locations for the file
	public ArrayList<String> getFileBlocksLocation(String fileName) throws IOException {
		ArrayList<String> FileBlockLocation = new ArrayList<>();
		BufferedReader bf = new BufferedReader(new FileReader(MASTERINFOFILE));
		String line = "";
		while ((line = bf.readLine()) != null) {
			/*
			 * Daniel First line (Filename), subsequent line DiskBlock;Hash;repeat
			 */
			String[] splittedLine = line.split(";");
			if (splittedLine[0].equals(fileName)) {
				line = bf.readLine();
				splittedLine = line.split(";");
				for (int i = 0; i < splittedLine.length; i += 2) {
					System.out.println("It stored at " + splittedLine[i]);
					String[] splittedLocation = splittedLine[i].split("B");
					FileBlockLocation.add(
							splittedLocation[0].substring(0, splittedLocation[0].length()) + "," + splittedLocation[1]);

				}
				break;
			}

		}
		bf.close();
		return FileBlockLocation;

	}

	//get all file names from Master Info File
	public ArrayList<String> getAllFilenames() throws IOException {
		ArrayList<String> fileNames = new ArrayList<>();
		BufferedReader bf = new BufferedReader(new FileReader(MASTERINFOFILE));
		String line = "";
		while ((line = bf.readLine()) != null) {

			// Daniel First line (Filename), subsequent line DiskBlock;Hash;repeat
			String[] splittedLine = line.split(";");
			fileNames.add(splittedLine[0]);
			System.out.println("Filenames:" + splittedLine[0]);
			line = bf.readLine();
		}
		bf.close();
		return fileNames;
	}

	//Checks the errors and return the list of error locations.
	public HashMap<Integer, ArrayList<String>> errorCheck(ArrayList<TransferManager> transferManagers)
			throws Exception {
		ArrayList<String> fileLocation = new ArrayList<>();
		ArrayList<String> hashnumber = new ArrayList<>();
		HashMap<Integer, ArrayList<String>> errorBlocks = new HashMap();
		BufferedReader bf = new BufferedReader(new FileReader(MASTERINFOFILE));
		HashManager hm = new HashManager();
		BufferedReader bf2 = new BufferedReader(new FileReader(PARITYINFOFILE));

		String line = "";
		while ((line = bf.readLine()) != null) {

			// Daniel First line (Filename), subsequent line DiskBlock;Hash;repeat

			String[] firstLine = line.split(";");
			// fileNamesNHash.add(firstLine[0]);
			// System.out.println("Filenames:" + firstLine[0]);
			// File hashes
			line = bf.readLine();
			String[] secLine = line.split(";");
			for (int i = 0; i < secLine.length; i += 2) {
				// System.out.println("It stored at " + secLine[i]);
				// Location of disk and block
				String[] splittedLocation = secLine[i].split("B");
				// fileLocation.add(splittedLocation[0].substring(1,
				// splittedLocation[0].length()) + "," + splittedLocation[1]);
				// hashnumber.add(secLine[i+1]);
				// Check file block and hash value.

				// Checking Local data
				// Path path = Paths.get(
				// getDiskPath(Integer.parseInt(splittedLocation[0].substring(1,
				// splittedLocation[0].length())))
				// + "/" + splittedLocation[1]);
				// File f = new File(path.toAbsolutePath().toString());
				// if (!f.exists()) {
				// if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
				// errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
				// }
				//// errorBlocks.get(Integer.parseInt(splittedLocation[1])).add(
				//// splittedLocation[0].substring(1, splittedLocation[0].length()) + "," +
				// splittedLocation[1]);
				// } else {
				// byte[] lines = Files.readAllBytes(path);
				// try {
				// if (!hm.hashString(lines).equals(secLine[i + 1])) {
				// if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
				// errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
				// }
				//// errorBlocks.get(Integer.parseInt(splittedLocation[1]))
				//// .add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
				//// + splittedLocation[1]);
				// }
				// } catch (NoSuchAlgorithmException e) {
				// // TODO Auto-generated catch block
				// e.printStackTrace();
				// }
				// }

				// Check disk server data
				String diskNo = splittedLocation[0].substring(1, splittedLocation[0].length());
				switch (diskNo) {
				case "0":
					if (transferManagers.get(0).receiveFile(splittedLocation[1], diskNo) == true) {
						// check
						// File test = new File();

						byte[] testline = Files
								.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
						try {
							if (!hm.hashString(testline).equals(secLine[i + 1])) {
								if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
									errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
								}
								errorBlocks.get(Integer.parseInt(splittedLocation[1]))
										.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
												+ splittedLocation[1]);
							}
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
							errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
						}
						errorBlocks.get(Integer.parseInt(splittedLocation[1]))
								.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
										+ splittedLocation[1]);
					}

					break;
				case "1":
					// transferManagers.get(1).receiveFile(splittedLocation[1]);
					if (transferManagers.get(1).receiveFile(splittedLocation[1], diskNo) == true) {
						// check
						// File test = new File();

						byte[] testline = Files
								.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
						try {
							if (!hm.hashString(testline).equals(secLine[i + 1])) {
								if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
									errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
								}
								errorBlocks.get(Integer.parseInt(splittedLocation[1]))
										.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
												+ splittedLocation[1]);
							}
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
							errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
						}
						errorBlocks.get(Integer.parseInt(splittedLocation[1]))
								.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
										+ splittedLocation[1]);
					}
					break;
				case "2":
					// transferManagers.get(2).receiveFile(splittedLocation[1]);
					if (transferManagers.get(2).receiveFile(splittedLocation[1], diskNo) == true) {
						// check
						// File test = new File();

						byte[] testline = Files
								.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
						try {
							if (!hm.hashString(testline).equals(secLine[i + 1])) {
								if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
									errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
								}
								errorBlocks.get(Integer.parseInt(splittedLocation[1]))
										.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
												+ splittedLocation[1]);
							}
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
							errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
						}
						errorBlocks.get(Integer.parseInt(splittedLocation[1]))
								.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
										+ splittedLocation[1]);
					}
					break;
				case "3":
					// transferManagers.get(3).receiveFile(splittedLocation[1]);
					if (transferManagers.get(3).receiveFile(splittedLocation[1], diskNo) == true) {
						// check
						// File test = new File();

						byte[] testline = Files
								.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
						try {
							if (!hm.hashString(testline).equals(secLine[i + 1])) {
								if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
									errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
								}
								errorBlocks.get(Integer.parseInt(splittedLocation[1]))
										.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
												+ splittedLocation[1]);
							}
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
							errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
						}
						errorBlocks.get(Integer.parseInt(splittedLocation[1]))
								.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
										+ splittedLocation[1]);
					}
					break;
				case "4":
					// transferManagers.get(4).receiveFile(splittedLocation[1]);
					if (transferManagers.get(4).receiveFile(splittedLocation[1], diskNo) == true) {
						// check
						// File test = new File();

						byte[] testline = Files
								.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + splittedLocation[1]));
						try {
							if (!hm.hashString(testline).equals(secLine[i + 1])) {
								if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
									errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
								}
								errorBlocks.get(Integer.parseInt(splittedLocation[1]))
										.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
												+ splittedLocation[1]);
							}
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
							errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
						}
						errorBlocks.get(Integer.parseInt(splittedLocation[1]))
								.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + ","
										+ splittedLocation[1]);
					}
					break;
				default:

					break;
				}// end switch

			}
		}
		bf.close();

		while ((line = bf2.readLine()) != null) {
			String[] secLine = line.split(";");

			// System.out.println("It stored at " + secLine[i]);
			// Location of disk and block
			String[] splittedLocation = secLine[0].split("p");
			String[] splittedLocation2 = secLine[2].split("q");
			// fileLocation.add(splittedLocation[0].substring(1,
			// splittedLocation[0].length()) + "," + splittedLocation[1]);
			// hashnumber.add(secLine[i+1]);
			// Check file block and hash value.

			// Checking Local parity p
			// Path path = Paths
			// .get(getDiskPath(Integer.parseInt(splittedLocation[0].substring(1,
			// splittedLocation[0].length())))
			// + "/" + "p" + splittedLocation[1]);
			// File f = new File(path.toAbsolutePath().toString());
			// if (!f.exists()) {
			// if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
			// errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
			// }
			//// errorBlocks.get(Integer.parseInt(splittedLocation[1]))
			//// .add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," +
			// "p"
			//// + splittedLocation[1]);
			// } else {
			// byte[] lines = Files.readAllBytes(path);
			// try {
			// if (!hm.hashString(lines).equals(secLine[0 + 1])) {
			// System.out.println(hm.hashString(lines) + "compair" + secLine[0 + 1]);
			// if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
			// errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
			// }
			//// errorBlocks.get(Integer.parseInt(splittedLocation[1]))
			//// .add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," +
			// "p"
			//// + splittedLocation[1]);
			// }
			// } catch (NoSuchAlgorithmException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// }

			// Check disk server p parity
			String diskNo = splittedLocation[0].substring(1, splittedLocation[0].length());
			switch (diskNo) {
			case "0":
				if (transferManagers.get(0).receiveFile("p" + splittedLocation[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "p" + splittedLocation[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[0 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation[1]))
									.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
											+ splittedLocation[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation[1]))
							.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
									+ splittedLocation[1]);
				}

				break;
			case "1":
				// transferManagers.get(1).receiveFile(splittedLocation[1]);
				if (transferManagers.get(1).receiveFile("p" + splittedLocation[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "p" + splittedLocation[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[0 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation[1]))
									.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
											+ splittedLocation[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation[1]))
							.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
									+ splittedLocation[1]);
				}
				break;
			case "2":
				// transferManagers.get(2).receiveFile(splittedLocation[1]);
				if (transferManagers.get(2).receiveFile("p" + splittedLocation[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "p" + splittedLocation[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[0 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation[1]))
									.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
											+ splittedLocation[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation[1]))
							.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
									+ splittedLocation[1]);
				}
				break;
			case "3":
				// transferManagers.get(3).receiveFile(splittedLocation[1]);
				if (transferManagers.get(3).receiveFile("p" + splittedLocation[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "p" + splittedLocation[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[0 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation[1]))
									.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
											+ splittedLocation[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation[1]))
							.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
									+ splittedLocation[1]);
				}
				break;
			case "4":
				// transferManagers.get(4).receiveFile(splittedLocation[1]);
				if (transferManagers.get(4).receiveFile("p" + splittedLocation[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "p" + splittedLocation[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[0 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation[1]))
									.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
											+ splittedLocation[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation[1]))
							.add(splittedLocation[0].substring(1, splittedLocation[0].length()) + "," + "p"
									+ splittedLocation[1]);
				}
				break;
			default:

				break;
			}// end switch

			// Checking Local parity q
			// path = Paths
			// .get(getDiskPath(Integer.parseInt(splittedLocation2[0].substring(1,
			// splittedLocation2[0].length())))
			// + "/" + "q" + splittedLocation2[1]);
			// f = new File(path.toAbsolutePath().toString());
			// if (!f.exists()) {
			// if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
			// errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
			// }
			//// errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
			//// .add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + ","
			// + "q"
			//// + splittedLocation2[1]);
			// } else {
			// byte[] lines = Files.readAllBytes(path);
			// try {
			// if (!hm.hashString(lines).equals(secLine[2 + 1])) {
			// System.out.println(hm.hashString(lines) + "compare" + secLine[0 + 1]);
			// if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
			// errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
			// }
			//// errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
			//// .add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + ","
			// + "q"
			//// + splittedLocation2[1]);
			// }
			// } catch (NoSuchAlgorithmException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// }

			// Check disk server q parity
			diskNo = splittedLocation2[0].substring(1, splittedLocation2[0].length());
			switch (diskNo) {
			case "0":
				if (transferManagers.get(0).receiveFile("q" + splittedLocation2[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "q" + splittedLocation2[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[2 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
									.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
											+ splittedLocation2[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
							.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
									+ splittedLocation2[1]);
				}

				break;
			case "1":
				// transferManagers.get(1).receiveFile(splittedLocation[1]);
				if (transferManagers.get(1).receiveFile("q" + splittedLocation2[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "q" + splittedLocation2[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[2 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
									.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
											+ splittedLocation2[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
							.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
									+ splittedLocation2[1]);
				}
				break;
			case "2":
				// transferManagers.get(2).receiveFile(splittedLocation[1]);
				if (transferManagers.get(2).receiveFile("q" + splittedLocation2[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "q" + splittedLocation2[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[2 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
									.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
											+ splittedLocation2[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
							.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
									+ splittedLocation2[1]);
				}
				break;
			case "3":
				// transferManagers.get(3).receiveFile(splittedLocation[1]);
				if (transferManagers.get(3).receiveFile("q" + splittedLocation2[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "q" + splittedLocation2[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[2 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
									.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
											+ splittedLocation2[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
							.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
									+ splittedLocation2[1]);
				}
				break;
			case "4":
				// transferManagers.get(4).receiveFile(splittedLocation[1]);
				if (transferManagers.get(4).receiveFile("q" + splittedLocation2[1], diskNo) == true) {
					// check
					// File test = new File();

					byte[] testline = Files
							.readAllBytes(Paths.get("./tempDisk" + diskNo + "/" + "q" + splittedLocation2[1]));
					try {
						if (!hm.hashString(testline).equals(secLine[2 + 1])) {
							if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
								errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
							}
							errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
									.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
											+ splittedLocation2[1]);
						}
					} catch (NoSuchAlgorithmException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				} else {
					if (!errorBlocks.containsKey(Integer.parseInt(splittedLocation2[1]))) {
						errorBlocks.put(Integer.parseInt(splittedLocation2[1]), new ArrayList());
					}
					errorBlocks.get(Integer.parseInt(splittedLocation2[1]))
							.add(splittedLocation2[0].substring(1, splittedLocation2[0].length()) + "," + "q"
									+ splittedLocation2[1]);
				}
				break;
			default:

				break;
			}// end switch

		}
		bf2.close();

		// Array of blocklocations that have errors.
		return errorBlocks;
	}

	
	//returns the size of the file
	public int getFileSize(String fileName) throws IOException {
		BufferedReader bf = new BufferedReader(new FileReader(MASTERINFOFILE));
		String line = "";
		while ((line = bf.readLine()) != null) {
			String[] splittedLine = line.split(";");
			if (splittedLine[0].equals(fileName)) {
				return Integer.parseInt(splittedLine[1]);
			}

		}
		bf.close();
		return 0;
	}

	//modify the number of disks in DiskConfig Properties file
	public void modifyDiskConfig(int numofDisk) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(getDiskConfigProperties()));
		bw.write("numofDisk=" + Integer.toString(numofDisk) + "\n");
		for (int i = 0; i < numofDisk; i++) {
			bw.write("D" + i + "=./Disk" + i + "\n");
		}
		bw.close();
	}

	//modify the block size in BlockSizeByte properties file
	public void modifyBlockConfig(int blockSize) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(getBlockSizeByteProperties()));
		bw.write("BlockSize=" + Integer.toString(blockSize));
		bw.close();
	}

	//returns DiskConfig properties file
	public String getDiskConfigProperties() {
		return DISKCONFIGFILE;
	}

	//returns BlockSizeByte properties file
	public String getBlockSizeByteProperties() {
		return BLOCKSIZEFILE;
	}

	//returns size of a disk
	public int getDiskSize() {
		return DiskSize;
	}

	//returns the number of strips that stores data
	public int getnumofStripswithInfo() { // this returns the strip numbers, if 0, means there are no data.
		int numofStripwithInfo = 0;
		int stripNumber = 0;
		for (int[] strip : BlockTable) {
			for (int b : strip) {
				if (b == 1) {
					numofStripwithInfo = stripNumber + 1;
				}
			}
			stripNumber++;
		}
		return numofStripwithInfo;
	}

	//check whether the file is already uploaded before
	public boolean isDuplicated(String fileName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(MASTERINFOFILE));
		String line = "";
		while ((line = br.readLine()) != null) {
			String[] splittedLine = line.split(";");
			if (splittedLine[0].equals(fileName)) {
				return true;
			}
			line = br.readLine();
		}
		br.close();
		return false;
	}

	public void reset() {
		//
	}

}
