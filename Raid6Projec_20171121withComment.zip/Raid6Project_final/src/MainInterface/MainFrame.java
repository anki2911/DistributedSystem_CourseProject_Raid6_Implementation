package MainInterface;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import BackEnd.DiskRemover;
import BackEnd.DiskWriter;
import BackEnd.DownloadManager;
import BackEnd.ErrorCorrection;
import BackEnd.EvenOddManager;
import BackEnd.ParityManager;
import BackEnd.RaidManager;
import BackEnd.TransferManager;

public class MainFrame {

	private JFrame frmRaidproject;
	private JButton btnUpload;
	private JButton btnDownload;
	private JButton btnRemove;
	private JButton btnErrorcheck;
	private JLabel lblNewLabel;
	private JPanel panel_3;
	private JLabel lblRaidProjectDemo;
	private JLabel lblGroupMember;

	private RaidManager rm = new RaidManager();
	private ParityManager pm = new ParityManager();
	private ErrorCorrection ec = new ErrorCorrection();
	private JList list;
	private JTextArea textArea_2;
	private JLabel lblBlockSizebyte;
	DefaultListModel dml = new DefaultListModel<>();
	private JButton btnUploadevenodd;
	// Daniel
	static final String LOCAL_HOST = "127.0.0.1";
	static final int DISKPORT_0 = 7490;
	static final int DISKPORT_1 = 7491;
	static final int DISKPORT_2 = 7492;
	static final int DISKPORT_3 = 7493;
	static final int DISKPORT_4 = 7494;
	// private TransferManager tm0 = new TransferManager(LOCAL_HOST, DISKPORT_0);
	// private TransferManager tm1 = new TransferManager(LOCAL_HOST, DISKPORT_1);
	// private TransferManager tm2 = new TransferManager(LOCAL_HOST, DISKPORT_2);
	// private TransferManager tm3 = new TransferManager(LOCAL_HOST, DISKPORT_3);
	// private TransferManager tm4 = new TransferManager(LOCAL_HOST, DISKPORT_4);
	ArrayList<TransferManager> transferManagers = new ArrayList();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame window = new MainFrame();
					window.frmRaidproject.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws IOException
	 */
	public MainFrame() throws IOException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @throws IOException
	 */
	private void initialize() throws IOException {
		for (int i = 0; i < 5; i++) {
			transferManagers.add(new TransferManager(LOCAL_HOST, DISKPORT_0 + i));
		}
		
		//initialize properties files and clean all disks
		rm = new RaidManager();
		rm.modifyDiskConfig(5); // as default
		rm.modifyBlockConfig(16); // as default 16384
		rm.resetBlockTable();
		rm.initDisk(rm.getnumofDisk());
		rm.initMasterInfo();
		rm.initParityInfo();
		EvenOddManager eom = new EvenOddManager(rm);
		// eom.makeDummyBlockTable();
		frmRaidproject = new JFrame();
		frmRaidproject.setTitle("Raid6Project");
		// Daniel setBounds(100, 100, 870, 570)
		frmRaidproject.setBounds(100, 100, 1006, 570);
		frmRaidproject.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmRaidproject.getContentPane().setLayout(null);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		frmRaidproject.setLocation(dim.width / 2 - frmRaidproject.getSize().width / 2,
				dim.height / 2 - frmRaidproject.getSize().height / 2);

		//show list of files in the panel
		list = new JList();
		list.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				if (list.getSelectedValue() != null) {
					String fileName = list.getSelectedValue().toString();
					try {
						showFileDetail(fileName, textArea_2, rm);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}

		});

		list.setModel(dml);

		//the area for printing log information
		JTextArea textArea_logger = new JTextArea();
		textArea_2 = new JTextArea();

		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		// Daniel (276, 6, 570, 60)
		panel.setBounds(276, 6, 706, 60);
		frmRaidproject.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		
		//upload button
		btnUpload = new JButton("Upload");
		btnUpload.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					uploadBtnEvent(dml, textArea_logger);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (NoSuchAlgorithmException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btnUpload.setBounds(28, 6, 104, 37);
		panel.add(btnUpload);

		
		
		//download button
		btnDownload = new JButton("Download");
		btnDownload.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("Downloading " + list.getSelectedValue());
				try {
					downloadBtnEvent(textArea_logger);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		// Daniel (164, 6, 104, 37)
		btnDownload.setBounds(209, 6, 104, 37);
		panel.add(btnDownload);

		//remove button
		btnRemove = new JButton("Remove");
		btnRemove.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					removeBtnEvent(dml, textArea_logger, textArea_2);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		// Daniel (295, 6, 104, 37);
		btnRemove.setBounds(385, 6, 104, 37);
		panel.add(btnRemove);

		//error check button
		btnErrorcheck = new JButton("ErrorCheck");
		// Daniel
		btnErrorcheck.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("Error Check Pressed");
				// try {
				try {
					errorCheckBtnEvent(textArea_logger);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				// } catch (IOException e1) {
				// TODO Auto-generated catch block
				// e1.printStackTrace();
				// }
			}
		});

		// Daniel (426, 6, 104, 37)
		btnErrorcheck.setBounds(561, 6, 104, 37);
		panel.add(btnErrorcheck);

		
		//the picture for raid6
		lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(MainFrame.class.getResource("/Resource/drive-slim-raid-4disks-icon.png")));
		lblNewLabel.setBounds(6, 59, 258, 269);
		frmRaidproject.getContentPane().add(lblNewLabel);

		panel_3 = new JPanel();
		panel_3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_3.setBounds(16, 340, 240, 152);
		frmRaidproject.getContentPane().add(panel_3);
		panel_3.setLayout(null);

		// JTextArea textArea = new JTextArea();
		// textArea.setBounds(115, 16, 94, 16);
		// panel_3.add(textArea);

		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(115, 44, 94, 16);
		panel_3.add(textArea_1);

		//set button to set number of disks and block size
		JButton btnSet = new JButton("Set");
		btnSet.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					// setBtnEvent(textArea, textArea_1, textArea_logger);
					setBtnEvent(textArea_1, textArea_logger);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnSet.setBounds(99, 100, 117, 29);
		panel_3.add(btnSet);

		// JLabel lblNumberOfDisk = new JLabel("Number of Disks:");
		// lblNumberOfDisk.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		// lblNumberOfDisk.setBounds(6, 16, 107, 16);
		// panel_3.add(lblNumberOfDisk);

		lblBlockSizebyte = new JLabel("Block Size (Byte):");
		lblBlockSizebyte.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		lblBlockSizebyte.setBounds(6, 44, 107, 16);
		panel_3.add(lblBlockSizebyte);

		JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setBounds(276, 78, 374, 257);
		frmRaidproject.getContentPane().add(scrollPane);

		scrollPane.setViewportView(list);

		JScrollPane scrollPane_1 = new JScrollPane();
		// Daniel Width was 184
		scrollPane_1.setBounds(662, 78, 320, 257);
		frmRaidproject.getContentPane().add(scrollPane_1);

		scrollPane_1.setViewportView(textArea_2);

		//Name of the project
		lblRaidProjectDemo = new JLabel("Raid6 Project");
		lblRaidProjectDemo.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblRaidProjectDemo.setBounds(80, 6, 108, 36);
		frmRaidproject.getContentPane().add(lblRaidProjectDemo);

		//print the name of the group memebers
		lblGroupMember = new JLabel("Group Members: Ankita Samaddar, Chen Zhe and Ng Jun Xian Daniel");
		lblGroupMember.setBounds(577, 504, 400, 16);
		frmRaidproject.getContentPane().add(lblGroupMember);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(276, 340, 374, 152);
		frmRaidproject.getContentPane().add(scrollPane_2);

		//button for evenodd encoding
		scrollPane_2.setViewportView(textArea_logger);
		btnUploadevenodd = new JButton("Upload (EvenOdd)");
		btnUploadevenodd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					uploadEvenOddBtnEvent(dml, textArea_logger);
				} catch (NumberFormatException | NoSuchAlgorithmException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnUploadevenodd.setBounds(694, 397, 160, 37);
		frmRaidproject.getContentPane().add(btnUploadevenodd);

	}

	//event for upload button
	public void uploadBtnEvent(DefaultListModel dml, JTextArea textArea_logger)
			throws IOException, NumberFormatException, NoSuchAlgorithmException {

		java.io.File file = null;
		// Daniel
		DiskWriter dw = new DiskWriter(rm, pm, transferManagers);
		DiskRemover dr = new DiskRemover();
		JFileChooser fileChooser = new JFileChooser();
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			file = fileChooser.getSelectedFile();

			if (!rm.isDuplicated(file.getName().toString())) {
				/*
				 * Daniel Add the upload function inside writeToDisk.
				 */

				dw.writeToDisk(file);

				// dw.writeEvenOddHorizontalParity();
				addFileList(file, dml);
				updateLogger("upload", file.getName(), textArea_logger);
			} else {

				String fileName = file.getName().toString();

				for (int i = 0; i < dml.getSize(); i++) {
					if (dml.get(i).toString().equals(fileName)) {

						// throw new Exception("Found "+dml.get(i).toString());

						dml.removeElementAt(i);
						clearFileDetail(fileName, textArea_2);
						dr.removeFilefromDisk(fileName, rm, pm, transferManagers);
						dw.writeToDisk(file);
						addFileList(file, dml);
						updateLogger("upload", file.getName(), textArea_logger);
					}
				}

				// updateLogger("remove", fileName, textArea_logger);

				System.out.println("File is already exist, updated");
			}

		} else {
			// System.out.println("No file has been chosen");
		}

	}

	//event for download button
	public void downloadBtnEvent(JTextArea textArea_logger) throws Exception {
		if (!list.isSelectionEmpty()) {
			java.io.File file = null;
			JFileChooser fileChooser = new JFileChooser();
			DownloadManager dm = new DownloadManager();

			errorCheckBtnEvent(textArea_logger);

			fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				file = fileChooser.getSelectedFile();

				System.out.println(file.getPath());
				dm.downloadFile(file, list.getSelectedValue().toString(), rm, transferManagers);
				updateLogger("download", list.getSelectedValue().toString(), textArea_logger);

			} else {
				// System.out.println("No file has been chosen");
			}
		} else {
			System.out.println("You did not choose any file for downloading!");
		}
	}

	//event for remove button
	public void removeBtnEvent(DefaultListModel dml, JTextArea textArea_logger, JTextArea textArea_2)
			throws IOException {

		DiskRemover dr = new DiskRemover();
		if (!list.isSelectionEmpty()) {
			String fileName = list.getSelectedValue().toString();
			if (list.getSelectedIndex() >= 0) {
				dml.removeElementAt(list.getSelectedIndex());
				updateLogger("remove", fileName, textArea_logger);
				clearFileDetail(fileName, textArea_2);
				dr.removeFilefromDisk(fileName, rm, pm, transferManagers);

			}
		} else {
			System.out.println("You did not choose any file for removing!");
		}
	}

	//event for error check button
	public void errorCheckBtnEvent(JTextArea textArea_logger) throws Exception {
		// Check MasterInfo.txt for
		// rm.getMasterInfo();

		int blockSize = rm.getBlockSize();
		int numofDisk = rm.getnumofDisk();
		// reinitalise the tempDisk folders for each error check
		rm.initTmpDisk(numofDisk);
		ArrayList<int[]> blockTable = rm.getBlockTable();

		
		//following code are used to check the locations of error blocks and recover them through Error Correction
		try {
			ErrorCorrection ec = new ErrorCorrection();
			HashMap<Integer, ArrayList<String>> ErrorBlockLocation = rm.errorCheck(transferManagers);
			Set<Integer> key = ErrorBlockLocation.keySet();
			for (int k : key) {
				for (String s : ErrorBlockLocation.get(k)) {

					System.out.println("Errorlist: " + s);
				}
			}

			Set<Integer> keySet = ErrorBlockLocation.keySet();
			for (int k : keySet) {
				int countP = 0;
				int countQ = 0;
				ArrayList<String> Strip = ErrorBlockLocation.get(k);
				if (Strip.size() > 2) {
					System.out.println("More than 2 disks failure, not able to recover");
					return;
					// Check for exactly 2 disk failures
				} else if (Strip.size() == 2) {
					System.out.println("2 block failure, recovering ...");
					for (String location : Strip) {
						String[] splittedLine = location.split(",");
						if (splittedLine[1].substring(0, 1).equals("p")) {
							countP++;
							System.out.println("countP" + countP);
						} else if (splittedLine[1].substring(0, 1).equals("q")) {
							countQ++;
							System.out.println("countQ" + countQ);
						}
					}
					// 2 parity
					// errors occur in p and q parities 
					if (countP > 0 && countQ > 0) {
						byte[][] healthyStrip = new byte[numofDisk - 2][blockSize];
						byte[][] recoveredData = new byte[2][blockSize];
						int counter = 0;
						for (int i = 0; i < numofDisk; i++) {
							String location = i + "," + k;

							String[] splittedLine = location.split(",");
							if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
									.parseInt(splittedLine[0])] != 0) {
								if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 1) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									healthyStrip[counter] = Files.readAllBytes(path);
									counter++;
								}
							} else {
								byte[] newbyte = new byte[blockSize];
								for (byte b : newbyte) {
									b = (byte) 0;

								}
								healthyStrip[counter] = newbyte.clone();
								counter++;
							}

						}

						recoveredData = ec.Missing_P_Q(blockSize, healthyStrip);
						for (int i = 0; i < Strip.size(); i++) {
							String recoverLocation = Strip.get(i);
							String[] splittedLine = recoverLocation.split(",");
							String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
							FileOutputStream fileOutputStream = new FileOutputStream(Strpath);
							fileOutputStream.write(recoveredData[i]);
							fileOutputStream.close();
							// Send the 2 parity to Disk servers
							switch (splittedLine[0]) {
							case "0":
								System.out.println("Sending Parity Data to Disk 0 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(0).sendFile(splittedLine[1], Strpath);
								break;
							case "1":
								System.out.println("Sending Parity Data to Disk 1 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(1).sendFile(splittedLine[1], Strpath);
								break;
							case "2":
								System.out.println("Sending Parity Data to Disk 2 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(2).sendFile(splittedLine[1], Strpath);
								break;
							case "3":
								System.out.println("Sending Parity Data to Disk 3 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(3).sendFile(splittedLine[1], Strpath);
								break;
							case "4":
								System.out.println("Sending Parity Data to Disk 4 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(4).sendFile(splittedLine[1], Strpath);
								break;
							default:

								break;
							}
						}

						//errors occur in p parity and one data block
					} else if (countP > 0 && countQ <= 0) {
						ArrayList<byte[]> healthyStrip = new ArrayList<>();
						byte[] Qblock = new byte[blockSize];
						byte[][] recoveredData = new byte[2][blockSize];
						int counter = 0;
						for (int i = 0; i < numofDisk; i++) {
							String location = i + "," + k;

							String[] splittedLine = location.split(",");
							if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
									.parseInt(splittedLine[0])] != 0) {

								if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 3) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + "q"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									// healthyStrip[counter] = Files.readAllBytes(path);
									Qblock = Files.readAllBytes(path);
								} else if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 1) {
									if (!Strip.contains(location)) {
										String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/"
												+ splittedLine[1];
										Path path = Paths.get(Strpath);
										File f = new File(Strpath);
										healthyStrip.add(Files.readAllBytes(path));
										// counter++;
									} else {
										healthyStrip.add(new byte[0]);
										// counter++;
									}
								}
							} else {
								byte[] newbyte = new byte[blockSize];
								for (byte b : newbyte) {
									b = (byte) 0;
								}
								healthyStrip.add(newbyte);
								// counter++;

							}

						}

						recoveredData = ec.MissingBlockDataAndP(blockSize, healthyStrip, Qblock);
						for (int i = 0; i < Strip.size(); i++) {
							String recoverLocation = Strip.get(i);
							String[] splittedLine = recoverLocation.split(",");
							String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
							FileOutputStream fileOutputStream = new FileOutputStream(Strpath);
							fileOutputStream.write(recoveredData[i]);
							fileOutputStream.close();
							// Send the p parity & 1 data to Disk servers
							switch (splittedLine[0]) {
							case "0":
								System.out.println("Sending p parity or data to Disk 0 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(0).sendFile(splittedLine[1], Strpath);
								break;
							case "1":
								System.out.println("Sending p parity or data to Disk 1 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(1).sendFile(splittedLine[1], Strpath);
								break;
							case "2":
								System.out.println("Sending p parity or data to Disk 2 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(2).sendFile(splittedLine[1], Strpath);
								break;
							case "3":
								System.out.println("Sending p parity or data to Disk 3 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(3).sendFile(splittedLine[1], Strpath);
								break;
							case "4":
								System.out.println("Sending p parity or data to Disk 4 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(4).sendFile(splittedLine[1], Strpath);
								break;
							default:

								break;
							}
						}
						//errors occur in q parity and one data block
					} else if (countP <= 0 && countQ > 0) {
						ArrayList<byte[]> healthyStrip = new ArrayList<>();
						byte[] Pblock = new byte[blockSize];
						byte[][] recoveredData = new byte[2][blockSize];
						int counter = 0;
						for (int i = 0; i < numofDisk; i++) {
							String location = i + "," + k;

							String[] splittedLine = location.split(",");
							if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
									.parseInt(splittedLine[0])] != 0) {
								if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 2) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + "p"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									// healthyStrip[counter] = Files.readAllBytes(path);
									Pblock = Files.readAllBytes(path);
								} else if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 1) {
									if (!Strip.contains(location)) {

										String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/"
												+ splittedLine[1];
										Path path = Paths.get(Strpath);
										File f = new File(Strpath);
										healthyStrip.add(Files.readAllBytes(path));
										// counter++;
									} else {
										healthyStrip.add(new byte[0]);
										// counter++;
									}
								}
							} else {
								byte[] newbyte = new byte[blockSize];
								for (byte b : newbyte) {
									b = (byte) 0;
								}
								healthyStrip.add(newbyte);
								// counter++;
							}

						}

						recoveredData = ec.MissingDataBlockAndQBlock(blockSize, healthyStrip, Pblock);
						for (int i = 0; i < Strip.size(); i++) {
							String recoverLocation = Strip.get(i);
							String[] splittedLine = recoverLocation.split(",");
							String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
							FileOutputStream fileOutputStream = new FileOutputStream(Strpath);
							fileOutputStream.write(recoveredData[i]);
							fileOutputStream.close();
							// Send the q parity & 1 data to Disk servers
							switch (splittedLine[0]) {
							case "0":
								System.out.println("Sending q parity or data to Disk 0 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(0).sendFile(splittedLine[1], Strpath);
								break;
							case "1":
								System.out.println("Sending q parity or data to Disk 1 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(1).sendFile(splittedLine[1], Strpath);
								break;
							case "2":
								System.out.println("Sending q parity or data to Disk 2 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(2).sendFile(splittedLine[1], Strpath);
								break;
							case "3":
								System.out.println("Sending q parity or data to Disk 3 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(3).sendFile(splittedLine[1], Strpath);
								break;
							case "4":
								System.out.println("Sending q parity or data to Disk 4 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(4).sendFile(splittedLine[1], Strpath);
								break;
							default:

								break;
							}
						}
						//error occur in two data blocks
					} else if (countP <= 0 && countQ <= 0) {
						ArrayList<byte[]> healthyStrip = new ArrayList<>();
						byte[] Pblock = new byte[blockSize];
						byte[] Qblock = new byte[blockSize];
						byte[][] recoveredData = new byte[2][blockSize];
						int counter = 0;
						for (int i = 0; i < numofDisk; i++) {
							String location = i + "," + k;
							String[] splittedLine = location.split(",");
							if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
									.parseInt(splittedLine[0])] != 0) {
								if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 2) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + "p"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									// healthyStrip[counter] = Files.readAllBytes(path);
									Pblock = Files.readAllBytes(path);

								} else if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 3) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + "q"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									// healthyStrip[counter] = Files.readAllBytes(path);
									Qblock = Files.readAllBytes(path);
								} else {
									if (!Strip.contains(location)) {

										String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/"
												+ splittedLine[1];
										Path path = Paths.get(Strpath);
										File f = new File(Strpath);
										healthyStrip.add(Files.readAllBytes(path));
										// counter++;
									} else {
										healthyStrip.add(new byte[0]);
									}
								}
							} else {
								byte[] newbyte = new byte[blockSize];
								for (byte b : newbyte) {
									b = (byte) 0;
								}
								healthyStrip.add(newbyte);
								// counter++;
							}

						}

						recoveredData = ec.missing2datablock(blockSize, healthyStrip, Pblock, Qblock);
						for (int i = 0; i < Strip.size(); i++) {
							String recoverLocation = Strip.get(i);
							String[] splittedLine = recoverLocation.split(",");
							String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
							FileOutputStream fileOutputStream = new FileOutputStream(Strpath);
							fileOutputStream.write(recoveredData[i]);
							fileOutputStream.close();
							// Send 2 data blocks to Disk servers
							switch (splittedLine[0]) {
							case "0":
								System.out.println("Sending datablocks to Disk 0 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(0).sendFile(splittedLine[1], Strpath);
								break;
							case "1":
								System.out.println("Sending datablocks to Disk 1 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(1).sendFile(splittedLine[1], Strpath);
								break;
							case "2":
								System.out.println("Sending datablocks data to Disk 2 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(2).sendFile(splittedLine[1], Strpath);
								break;
							case "3":
								System.out.println("Sending datablocks to Disk 3 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(3).sendFile(splittedLine[1], Strpath);
								break;
							case "4":
								System.out.println("Sending datablocks to Disk 4 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(4).sendFile(splittedLine[1], Strpath);
								break;
							default:

								break;
							}
						}
					}
					//only one block error in this strip
				} else if ((Strip.size() == 1)) {
					System.out.println("1 block failure, recovering ...");
					for (String location : Strip) {
						String[] splittedLine = location.split(",");
						if (splittedLine[1].substring(0, 1).equals("p")) {
							countP++;
							System.out.println("countP" + countP);
						} else if (splittedLine[1].substring(0, 1).equals("q")) {
							countQ++;
							System.out.println("countQ" + countQ);
						}
					}
					//error occure in p parity block
					if (countP > 0) {
						byte[][] healthyStrip = new byte[numofDisk - 2][blockSize];
						byte[] recoveredData = new byte[blockSize];
						int counter = 0;
						for (int i = 0; i < numofDisk; i++) {
							String location = i + "," + k;
							if (!Strip.contains(location)) {
								String[] splittedLine = location.split(",");
								if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 1) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									healthyStrip[counter] = Files.readAllBytes(path);
									counter++;
								} else if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 0) {
									for (byte b : healthyStrip[counter]) {
										b = (byte) 0;
									}
									counter++;
								}

							}

						}

						recoveredData = ec.MissingPBlock(blockSize, healthyStrip);
						for (int i = 0; i < Strip.size(); i++) {
							String recoverLocation = Strip.get(i);
							String[] splittedLine = recoverLocation.split(",");
							String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
							FileOutputStream fileOutputStream = new FileOutputStream(Strpath);
							fileOutputStream.write(recoveredData);
							fileOutputStream.close();
							// Send 1 p parity to Disk servers
							switch (splittedLine[0]) {
							case "0":
								System.out.println("Sending p parity to Disk 0 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(0).sendFile(splittedLine[1], Strpath);
								break;
							case "1":
								System.out.println("Sending p parity to Disk 1 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(1).sendFile(splittedLine[1], Strpath);
								break;
							case "2":
								System.out.println("Sending p parity data to Disk 2 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(2).sendFile(splittedLine[1], Strpath);
								break;
							case "3":
								System.out.println("Sending p parity to Disk 3 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(3).sendFile(splittedLine[1], Strpath);
								break;
							case "4":
								System.out.println("Sending p parity to Disk 4 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(4).sendFile(splittedLine[1], Strpath);
								break;
							default:

								break;
							}
						}
						//error occure in q parity
					} else if (countQ > 0) { // checked
						byte[][] healthyStrip = new byte[numofDisk - 2][blockSize];
						byte[] recoveredData = new byte[blockSize];
						int counter = 0;
						for (int i = 0; i < numofDisk; i++) {
							String location = i + "," + k;
							if (!Strip.contains(location)) {
								String[] splittedLine = location.split(",");
								if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 1) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									healthyStrip[counter] = Files.readAllBytes(path);
									counter++;
								} else if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
										.parseInt(splittedLine[0])] == 0) {
									for (byte b : healthyStrip[counter]) {
										b = (byte) 0;
									}
									counter++;
								}

							}

						}

						recoveredData = ec.MissingQBlock(blockSize, healthyStrip);
						for (int i = 0; i < Strip.size(); i++) {
							String recoverLocation = Strip.get(i);
							String[] splittedLine = recoverLocation.split(",");
							String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
							FileOutputStream fileOutputStream = new FileOutputStream(Strpath);
							fileOutputStream.write(recoveredData);
							fileOutputStream.close();
							// Send q parity to Disk servers
							switch (splittedLine[0]) {
							case "0":
								System.out.println("Sending q parity to Disk 0 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(0).sendFile(splittedLine[1], Strpath);
								break;
							case "1":
								System.out.println("Sending q parity to Disk 1 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(1).sendFile(splittedLine[1], Strpath);
								break;
							case "2":
								System.out.println("Sending q parity data to Disk 2 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(2).sendFile(splittedLine[1], Strpath);
								break;
							case "3":
								System.out.println("Sending q parity to Disk 3 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(3).sendFile(splittedLine[1], Strpath);
								break;
							case "4":
								System.out.println("Sending q parity to Disk 4 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(4).sendFile(splittedLine[1], Strpath);
								break;
							default:

								break;
							}
						}
						//error occur in data block
					} else { // checked
						byte[][] healthyStrip = new byte[numofDisk - 2][blockSize];
						byte[] Pblock = new byte[blockSize];
						byte[] recoveredData = new byte[blockSize];
						int counter = 0;
						for (int i = 0; i < numofDisk; i++) {
							String location = i + "," + k;

							String[] splittedLine = location.split(",");
							if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
									.parseInt(splittedLine[0])] == 1) {
								if (!Strip.contains(location)) {
									String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/"
											+ splittedLine[1];
									Path path = Paths.get(Strpath);
									File f = new File(Strpath);
									healthyStrip[counter] = Files.readAllBytes(path);
									counter++;
								} else {
									for (byte b : healthyStrip[counter]) {
										b = (byte) 0;

									}
									counter++;
								}

							} else if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
									.parseInt(splittedLine[0])] == 2) {
								String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + "p"
										+ splittedLine[1];
								Path path = Paths.get(Strpath);
								File f = new File(Strpath);
								// healthyStrip[counter] = Files.readAllBytes(path);
								Pblock = Files.readAllBytes(path);
							} else if (blockTable.get(Integer.parseInt(splittedLine[1]))[Integer
									.parseInt(splittedLine[0])] == 3) {
								// String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" +
								// "q"
								// + splittedLine[1];
								// Path path = Paths.get(Strpath);
								// File f = new File(Strpath);
								// healthyStrip[counter] = Files.readAllBytes(path);
							}

							else {
								for (byte b : healthyStrip[counter]) {
									b = (byte) 0;

								}
								counter++;
							}

						}

						recoveredData = ec.Missing1BlockData(blockSize, healthyStrip, Pblock);
						for (int i = 0; i < Strip.size(); i++) {
							String recoverLocation = Strip.get(i);
							String[] splittedLine = recoverLocation.split(",");
							String Strpath = rm.getDiskPath(Integer.parseInt(splittedLine[0])) + "/" + splittedLine[1];
							FileOutputStream fileOutputStream = new FileOutputStream(Strpath);
							fileOutputStream.write(recoveredData);
							fileOutputStream.close();
							// Send 1 data block to Disk servers
							switch (splittedLine[0]) {
							case "0":
								System.out.println("Sending datablock to Disk 0 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(0).sendFile(splittedLine[1], Strpath);
								break;
							case "1":
								System.out.println("Sending datablock to Disk 1 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(1).sendFile(splittedLine[1], Strpath);
								break;
							case "2":
								System.out.println("Sending datablock data to Disk 2 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(2).sendFile(splittedLine[1], Strpath);
								break;
							case "3":
								System.out.println("Sending datablock to Disk 3 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(3).sendFile(splittedLine[1], Strpath);
								break;
							case "4":
								System.out.println("Sending datablock to Disk 4 Server");
								System.out.println("recovered Filename " + splittedLine[1]);
								transferManagers.get(4).sendFile(splittedLine[1], Strpath);
								break;
							default:

								break;
							}
						}
					}
				}

			}

			updateLogger("errorCheck", null, textArea_logger);

		} catch (

		IOException e) {
			e.printStackTrace();
		}
	}

	// public void setBtnEvent(JTextArea diskNumberinput, JTextArea blockSizeinput,
	// JTextArea textArea_logger)
	
	
	//event for set number of disks and block size
	public void setBtnEvent(JTextArea blockSizeinput, JTextArea textArea_logger) throws IOException {
		// if ((!diskNumberinput.getText().isEmpty()) &&
		// (!blockSizeinput.getText().isEmpty())) {
		if (!blockSizeinput.getText().isEmpty()) {
			// int diskNumber = Integer.parseInt(diskNumberinput.getText().toString());
			int blockSize = Integer.parseInt(blockSizeinput.getText().toString());
			rm = new RaidManager();
			// rm.modifyDiskConfig(diskNumber);
			rm.modifyBlockConfig(blockSize);
			rm.resetBlockTable();
			// rm.initDisk(rm.getnumofDisk());
			rm.initMasterInfo();
			dml.clear();
			textArea_2.setText("");
			updateLogger("set", null, textArea_logger);

		} else {
			System.out.println("Please input numbers for disk numbers and block size.");
		}

	}

	//add item to file list panel
	public void addFileList(java.io.File file, DefaultListModel dml) {
		dml.addElement(file.getName());
	}

	//show detail of a file when user click the file in the panel
	public void showFileDetail(String fileName, JTextArea jtextArea, RaidManager rm) throws IOException {
		BufferedReader bf = new BufferedReader(new FileReader(rm.getMasterInfo()));
		String line;
		String detail = "";
		while ((line = bf.readLine()) != null) {
			String[] splittedLine = line.split(";");
			if (splittedLine[0].equals(fileName)) {
				detail += splittedLine[0] + ":(Location;Hash)\n";
				line = bf.readLine();
				splittedLine = line.split(";");
				for (int i = 0; i < splittedLine.length; i += 2) {
					detail += splittedLine[i] + ";" + splittedLine[i + 1] + "\n";
				}
			}
		}
		if (detail.isEmpty()) {
			detail = "Cannot find info";
		}
		jtextArea.setText(detail);
		bf.close();

	}

	//clear the file detail in the interface
	public void clearFileDetail(String fileName, JTextArea textArea_2) {
		textArea_2.setText("");
	}

	
	//print the log information on interface
	public void updateLogger(String action, String fileName, JTextArea textArea_logger) {
		switch (action) {
		case "upload":
			textArea_logger.append("upload file \"" + fileName + "\" successfully!\n");
			break;
		case "download":
			textArea_logger.append("download file \"" + fileName + "\" successfully!\n");
			break;
		case "remove":
			textArea_logger.append("remove file \"" + fileName + "\"successfully!\n");
			break;
		case "set":
			textArea_logger.append("set Configuration successfully!\n");
			break;
		case "uploadEvenOdd":
			textArea_logger.append("upload file \"" + fileName + "\" with EvenOdd parity successfully!\n");
			break;
		case "errorCheck":
			textArea_logger.append("Error Check Complete!\n");
			break;
		default:

			break;
		}
	}

	//event for uploading file with parity generated by evenodd coding scheme
	public void uploadEvenOddBtnEvent(DefaultListModel dml, JTextArea textArea_logger) throws Exception {
		java.io.File file = null;
		DiskWriter dw = new DiskWriter(rm);
		JFileChooser fileChooser = new JFileChooser();
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			file = fileChooser.getSelectedFile();

			if (!rm.isDuplicated(file.getName().toString())) {
				dw.writeToDisk(file);
				addFileList(file, dml);
				dw.writeEvenOddHorizontalParity();
				dw.writeEvenOddDiagonalParity();
				updateLogger("uploadEvenOdd", file.getName(), textArea_logger);
			} else {
				System.out.println("File is already exist");
			}

		} else {
			// System.out.println("No file has been chosen");
		}
	}
}
